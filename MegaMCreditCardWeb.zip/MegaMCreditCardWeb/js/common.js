/* 當 MODE = DEV，電文回傳mock資料
   當 MODE = DEV_WITH_CONTROL，電文回傳mock資料，timer倒數機制與頁面流程控制啟用
   當 MODE = UAT_SELF，為本機測試模式
   當 MODE = UAT，為兆豐測試模式
   當 MODE = PDT，為兆豐正式模式 */
var Environment = {
	MODE: "PDT"
};

// 一般通用常數
var CommonConstant = {
	HOME_PAGE_URL: "https://www.megabank.com.tw/",
	PC_VERSION_URL: "https://ebank.megabank.com.tw/global2/as/as05/PAS50_Login.faces?_ga=2.185744489.1535354578.1512538345-1638537417.1509085628",
	SERVICE_LOCATION_URL: "https://www.megabank.com.tw/about/about04.asp",
	// ONLINE_DOCUMENT_URL: "https://creditcard.megabank.com.tw/megaweb/Index_CardApply.asp",
	
	GATEWAY_PDT_URL: "https://ebank.megabank.com.tw/MegaMCreditCard/rest/creditcard/",
	GATEWAY_UAT_URL: "https://192.168.53.157:452/MegaMCreditCard/rest/creditcard/",
	
	IFRAME_PDT_USERVRFY: "https://netbank.megabank.com.tw/natm/NETATM?channelID=UserVrfy&SourceID=001&SourceType=D",
	IFRAME_UAT_USERVRFY: "https://192.168.53.157:452/natm/NETATM?channelID=UserVrfy&SourceID=001&SourceType=D",

	DOC_RESEND_MAILTO: "mailto:is@megacard.com.tw?subject=Apply for credit card&body=Name:",
	
	ARTICLE_CODE_PREFIX: "article_",
	MEGABANK_ARTICLE_PREFIX: "C",
	
	CARD_TYPE_MEGABANK: "1",
	CARD_TYPE_OTHERS: "9",
	CARD_TYPE_USERVRFY: "17",
	// CARD_TYPE_ONLINE_DOCUMENT: "999",
	
	IDENTIFY_TYPE_MEGABANK: "2",
	IDENTIFY_TYPE_OTHERS: "3",
	IDENTIFY_TYPE_USERVRFY: "5",
	
	// 本行正卡申請IS_ORIGIN，他行IS_NOT_ORIGIN，存戶IS_USERVRFY
	IS_ORIGIN: "1",
	IS_NOT_ORIGIN: "0",
	IS_USERVRFY: "2",

	// 職務類別選單，對應代碼
	MENU_JOB_FREELANCE: "8",
	MENU_JOB_STUDENT: "10",
	MENU_JOB_OTHERS: "11",
	
	// 信用卡領取方式
	CARD_TO_BY_POST: "1",
	CARD_TO_BY_SELF: "4",

	// 簡訊OTP完整倒數秒數
	DEFAULT_SMS_OTP_COUNTDOWN_SEC: 180,

	UPLOAD_PIC_PREFIX: "P5_",
	UPLOAD_PIC_EXT: ".jpg",
	UPLOAD_XML_POSTFIX_WITH_FILE_EXT: "M.xml"
};

// 定義LocalStorage key
var LSKey = {
	ERROR_MSG: "errorMsg",

	QUERY_CODE: "queryCode",

	CM010_RQ_DATA: "CM010RqData",
	VR012_RQ_DATA: "VR012RqData",
	
	CM002_RS_DATA: "CM002RsData",
	VR012_RS_DATA: "VR012RsData",

	TOKEN_ID: "tokenID",
	TOKEN_TIME: "tokenTime",
	TIMEOUT_ALERT_TIME: "timeoutAlertTime",
	AES_KEY: "aesKey",

	CURRENT_HTML: "currentHtml",
	PREVIOUS_HTML: "previousHtml",
	
	TARGET_CREDIT_CARD: "targetCreditCard",

	IMAGE_IDFILE_F: "idFileF",
	IMAGE_IDFILE_B: "idFileB",
	ATTACHEMENTS_NAME_ARY: "attachmentsNameAry",

	ADDR1_CITY: "cPrimAddr1City",
	ADDR2_CITY: "cPrimAddr2City",
	ADDR3_CITY: "cPrimAddr3City",

	HAS_APPLICATION_SUBMIT: "hasApplicationSubmit",
	APPLICATION_FAIL_COUNT: "applicationFailCount",

	CARD_FRIEND_INFO: "cardFriendInfo",
	SMS_OTP_INFO: "smsOtpInfo"
};

/** 逾時倒數控制 */
function startTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.clear();
	singletonTimer.start();
}

function stopTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.clear();
}

function restartTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.restart();
}

// slide 方向 上-下 的toast訊息
function showToast(message) {
	if($(".c-toast-loader").length == 0) {
		$(".c-page-container").append("<div class='c-toast-loader'></div>");
	}

	var toastLoader = $(".c-toast-loader");
	toastLoader.empty();
	toastLoader.load("components/toast.html", function() {
		// 僅控制非disabled狀態的按鈕
		var $targetBtn = $(".c-btn--purple:not(:disabled)");
		$targetBtn.prop('disabled', true);

		$(".c-toast__message").text(message);
		toastLoader.addClass("slide-in__top");
		toastLoader.show();

		setTimeout(function() {
			toastLoader.addClass("slide-out__top");

			setTimeout(function() {
		    	toastLoader.hide();
		    	toastLoader.removeClass("slide-in__top");
				toastLoader.removeClass("slide-out__top");

				$targetBtn.prop('disabled', false);
			}, 500);
		}, 5000);
	});
}

// 錯誤彈出訊息
function showErrAlert(error){
	var errContent = '';

	if($.type(error) == 'string'){
		errContent = error;
	}else{
		var errorMsgAry = [];
		$.each(error,function(index,value){
			// 避免訊息重複
			var msg = error[index].message;
			var idx = errorMsgAry.indexOf(msg);
			if(idx === -1) {
				errContent += '<div style="margin-bottom: .5em;">' + msg + '</div>';
				errorMsgAry.push(msg);
			}
		});
	}

	if($(".errMsg").length == 0) {
		$(".c-page-container").append("<div class='c-modal u-display--none errMsg'></div>");
	}

	var errMsgView = $(".errMsg");
	errMsgView.empty();
	errMsgView.load("components/errorMsg.html", function() {
	
		$("#errContent").html(errContent);

		$(".errMsg .c-modal__act-bar .c-btn").unbind();
	    $(".errMsg .c-modal__act-bar .c-btn").bind("click", function() {
	    	$.unblockUI();
	    });
		
	});

	if($(".errMsg").length != 0) {

		var modal = $(".errMsg");
	    $.blockUI({
			message : modal,
			fadeIn: 0,
			css : {
				cursor : null,
				height : modal.height() + 'px',
				top : '12%',
				left : '50%',
				width : '80%',
				maxWidth : '800px',
				transform : 'translate(-50%,-50%)',
				border: 'none',
				'-webkit-border-radius': '5px',
				'-moz-border-radius': '5px',
				'border-radius': '5px',
				backgroundColor: 'white'
			}
		});
	}

}

/* 
* 比對頁面元件(element)是否存在於jquery.validate錯誤列表(errorList)中
* 若存在，回傳非-1 index
*/
function matchErrorElementByName(errorList, element) {
	var index = -1;

	if(element && errorList && errorList.length > 0) {
		for(var i = 0; i != errorList.length; i++) {
			if(errorList[i].element.name === element.name) {
				index = i;
				break;
			}
		}
	}

	return index;
}

// 彈出條款內容
function showTillCuan(htmlContent){

	if($(".tillcuan").length == 0) {
		$(".c-page-container").append("<div class='c-modal u-display--none tillcuan'></div>");
	}

	var articelView = $(".tillcuan");
	articelView.empty();
	articelView.load("components/article.html", function() {
	
		$("#articleContent").html(stripXSS(htmlContent));

		$(".tillcuan .c-modal__act-bar .c-btn").unbind();
	    $(".tillcuan .c-modal__act-bar .c-btn").bind("click", function() {
	    	$.unblockUI();
	    });
		
	});

	if($(".tillcuan").length != 0) {

		var modal = $(".tillcuan");
	    $.blockUI({
			message : modal,
			fadeIn: 0,
			css : {
				cursor : null,
				height : '400px',
				top : '45%',
				left : '50%',
				width : '80%',
				maxWidth : '800px',
				transform : 'translate(-50%,-50%)',
				border: 'none',
				'-webkit-border-radius': '5px',
				'-moz-border-radius': '5px',
				backgroundColor: 'rgba(48,48,48,0.85)'
			}
		});
	}

}


// slide 方向 右-左 的條款內容頁
function showArticle(htmlContent) {
	$(".c-article-item__checkbox input[type='checkbox']").prop("disabled", true);

	if($(".c-article-loader").length == 0) {
		$(".c-page-container").append("<div class='c-article-loader'></div>");
	}

	var articleLoader = $(".c-article-loader");

	var body = document.body;
	var html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight );

	articleLoader.width("100%");
	articleLoader.height(height);

	articleLoader.empty();
	articleLoader.load("components/articleDetail.html", function() {
		// 移動至頁面頂端
		$("html, body").scrollTop(0);

		$(".c-article-detail__content").html(stripXSS(htmlContent));
		articleLoader.addClass("slide-in__right");
		articleLoader.show();

		$(".c-article-detail__go-back").bind("click", hideArticle);
	});
}

function hideArticle() {
	$(".c-article-item__checkbox input[type='checkbox']").prop("disabled", false);

	var articleLoader = $(".c-article-loader");

	articleLoader.addClass("slide-out__right");

	setTimeout(function() {
    	articleLoader.hide();
    	articleLoader.removeClass("slide-in__right");
		articleLoader.removeClass("slide-out__right");
	}, 1000);
}

//展開條款內容
function expendTillCuan(element){
	var articleKey = element.data("article-key");
	var htmlContent = decodeArticleContent(articleKey);

	if($(".c-article-expender-"+articleKey).length == 0) { 
		element.parent().after("<div class='c-article-expender c-article-expender-"+articleKey+"'></div>");
	}
	var windowHeight = $(window).height();
	//綁定底下條文區塊
	var articleExpender = $(".c-article-expender-"+articleKey);
	articleExpender.height(windowHeight*0.3);
	articleExpender.html(stripXSS(htmlContent));
	element.addClass('expend-up');
	articleExpender.show();
	
	element.bind("click", hideTillCuan);
	
}

//縮起條款內容
function hideTillCuan(){
	var articleKey = $(this).data("article-key");

	var articleExpender = $(".c-article-expender-"+articleKey);
	articleExpender.hide();
	$(this).removeClass("expend-up");
	$(this).unbind("click", hideTillCuan);
}

// 條款項目與checkbox連動控制
function setArticleControl() {
	// 條款項目點擊後連動勾選checkbox
	$(".c-article-item__title").bind("click", function() {
		// showArticle(decodeArticleContent($(this).data("article-key")));
		//showTillCuan(decodeArticleContent($(this).data("article-key")));
		expendTillCuan($(this));
		$("#" + $(this).data("article-key")).prop("checked", true);
	});

	// checkbox勾選連動帶出條款內容頁
	$(".c-article-item__checkbox input[type='checkbox']").change(function() {
		if($(this).prop("checked")) {
			// showArticle(decodeArticleContent($(this).prop("id")));
			expendTillCuan($(this).parent().next());
		}
	});
}

// 將checkbox設置為單選
function setCheckBoxExclusive(checkBoxName) {
	$("input[name='" + checkBoxName + "']").each(function() {
		$(this).bind("click", function() {
			$("input[name='" + checkBoxName + "']:checked").prop("checked", false);
			$(this).prop("checked", true);
		});
	});
}

// 設定進度條圖示，本行卡申請流程或其他
function setProcessImg(isOrigin) {
	if(CommonConstant.IS_ORIGIN === isOrigin) {
		$("img[data-name='isOrigin']").show();
	} else {
		$("img[data-name='isNotOrigin']").show();
	}
}

// LocalStorage記錄目前與前一頁面
function updatePageNavInfo() {
	var currentUrl = document.location.pathname;
	var currentUrlSplit = currentUrl.split("/");
	var currentHtml = currentUrlSplit[currentUrlSplit.length - 1]

	if(currentHtml !== localStorage.getItem(LSKey.CURRENT_HTML)) {
		localStorage.setItem(LSKey.PREVIOUS_HTML, localStorage.getItem(LSKey.CURRENT_HTML));
		localStorage.setItem(LSKey.CURRENT_HTML, currentHtml);
	}
}

function doCancel() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

// 字串左邊補0直到字串長度為totalLength
function appendPrefixZero(content, totalLength) {
	var result = "";
	if(content) {
		var count = totalLength - content.length;
		var zeroStr = "";
		if(count > 0) {
			for(var i = 0; i < count; i++) {
				zeroStr += "0";
			}
		}
		result = zeroStr + content;
	}
	return result;
}

function removePrefixZero(content) {
	return parseInt(content).toString();
}

// 字串隱碼處理 getStrMask('A123456789', 5, 7, '*') => A123***789
function getStrMask(inputStr, start, end, tokenChar) {
	var result = "";
	if(inputStr){
		var tokenLength = end - start + 1;
		if(tokenLength && tokenLength > 0) {
			var strPrefix = inputStr.substring(0, start - 1);
			var strPostfix = inputStr.substring(end);
			var tokenText = '';

			for(var i = 0; i != tokenLength; i++) {
				tokenText += tokenChar;
			}
			result = strPrefix + tokenText + strPostfix;
		}
	}
	return result;
}

function decodeArticleContent(articleKey) {
	var articleJSON = localStorage.getItem(articleKey);

	if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
		return JSON.parse(articleJSON).article;
	} else {
		return decodeURIComponent(window.atob(JSON.parse(articleJSON).article).replace(/\+/g, "%20"));
	}
}

function showErrorPage(errorMsg) {
	// 保留query code，供錯誤頁返回時串接參數
	var queryCodeJSON = localStorage.getItem(LSKey.QUERY_CODE);

	clearWebStorage();

	if(queryCodeJSON) {
		localStorage.setItem(LSKey.QUERY_CODE, queryCodeJSON);
	}

	localStorage.setItem(LSKey.ERROR_MSG, errorMsg);
	location.href = "errorPage.html";
	throw new Error();
}

function clearWebStorage() {
	localStorage.clear();
	sessionStorage.clear();
}

// 檢核必要的LocalStorage data是否存在
function checkLocalStorage(LSKeyArray) {
	var isValid = true;
	if(LSKeyArray) {
		LSKeyArray.forEach(function(key) {
			if(!localStorage.getItem(key)) {
				isValid = false;
				showErrorPage("驗證資訊有誤！請重新申請");
			}
		});
		return isValid;
	}
}

// 判斷使用的瀏覽器是否為行動裝置的瀏覽器
function checkUserAgent() {
	if(Environment.MODE !== "PDT") {
		return true;
	}

	var isValid = true;
	var userAgent = navigator.userAgent;
	if(!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
		isValid = false;
		showErrorPage("請使用電腦版申請頁面進行信用卡線上申請");
	}
	return isValid;
}

// 判斷是否為手機裝置
function isMobile() {
	var isMobileFlag = false;
	var userAgent = navigator.userAgent;
	if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
		isMobileFlag = true;
	}
	return isMobileFlag;
}

// 畫面scroll至頁面元件，主要用在表單欄位檢核
(function($) {
    $.fn.goTo = function() {
    	var offset = 0;
    	if($(this).is(":visible")) {
			offset = $(this).offset().top;
    	} else {
			offset = $(this).parent().offset().top;
    	}

        $('html, body').animate({
            scrollTop: offset - 65 + 'px'	// 避免被toast覆蓋
        }, 'fast');
        return this;
    }
})(jQuery);

// 字串全域替換
String.prototype.replaceAll = function(search, replacement) {
	var target = this;
	return target.replace(new RegExp(search, 'g'), replacement);
};

// 上一步鈕
function goBack() {
	window.history.back();
}

// 以選單文字取得option jquery物件
function jqGetOptionbyText(selectName, text) {
	return $("select[name='" + selectName + "'] option").filter(function () {
		return $(this).html() == text;
	});
}

// XSS過濾
function stripXSS(content) {
	var result = content;
	var patterns = [
		/<script[\s\S]*?>[\s\S]*?<\/script>/gi, 
		/eval\((.*?)\)/gi, 
		/expression\((.*?)\)/gi, 
		/javascript:/gi, 
		/vbscript:/gi, 
		/onload(.*?)=/gi
	];
	patterns.forEach(function(pattern) {
		result = result.replace(pattern, "");
	});

	return result;
}

function showLoadingView() {
	if($("#loader").length == 0) {
		$(".c-page-container").append('<div id="loader"></div>');
	}

	var modal = $("#loader");
	modal.addClass("loading__circle");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			width : ($(window).width() * 0.7) + 'px',
			height : modal.height() + 'px',
			top : '25%',
			left : (($(window).width() * 0.3) / 2) + 'px',
			border: 'none',
			backgroundColor: 'transparent'
		}
	});
}

function hideLoadingView() {
	$.unblockUI();
	$("#loader").removeClass("loading__circle");
}

//email格式：須包含一個「＠」與一個（含）以上的「.」
function isEmailValid(email) {
	var isEmailValid = false;
	var atSignCount = email.length - email.replaceAll("@", "").length;
	console.log('atSignCount: ' + atSignCount);
	if(atSignCount === 1 && email.indexOf(".") !== -1 && 
		email.indexOf(".@") === -1 && email.indexOf("@.") === -1 &&
		email.indexOf(" ") === -1) {
		isEmailValid = /^[^\u4E00-\u9FA5]*$/g.test(email);
	}
	return isEmailValid;
}

function iFrameUrl() {
	if(Environment.MODE === "PDT") {
		return CommonConstant.IFRAME_PDT_USERVRFY;
	} else if (Environment.MODE === "UAT"){
		return CommonConstant.IFRAME_UAT_USERVRFY;
	} else {
		return "http://127.0.0.1:8080/MegaMCreditCardWeb/test_iframe.html?channelID=UserVrfy&SourceID=001&SourceType=D";
	}
}

function geteway_url() {
	if(Environment.MODE === "PDT") {
		return CommonConstant.GATEWAY_PDT_URL;
	} else if (Environment.MODE === "UAT") {
		return CommonConstant.GATEWAY_UAT_URL;
	} else if (Environment.MODE === "UAT_SELF"){
		return "http://127.0.0.1:8080/MegaMCreditCard/rest/creditcard/";
	} else {
		return "";
	}
}

// 將數位軌跡(Piwik)setSiteId與環境變數連動
function getPiwikSiteId() {
	if(Environment.MODE === "PDT") {
		return '3';
	} else if(Environment.MODE === "UAT") {
		return '4';
	} else {
		return '';
	}
}
