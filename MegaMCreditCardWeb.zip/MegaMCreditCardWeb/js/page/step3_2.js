$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.HAS_APPLICATION_SUBMIT])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		setProcessImg(CM010RqDataObj.isOrigin);

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
		$("button[name='nextButton']").hide();
		$("button[name='submitButton']").show();
	} else {
		$("button[name='nextButton']").show();
		$("button[name='submitButton']").hide();
	}

	loadArticle();

	setArticleControl();

	$("a[name='docResendMailLink']").attr("href", CommonConstant.DOC_RESEND_MAILTO);
}

function loadArticle() {
	var articleLoaders = $(".articleLoader");
	articleLoaders.each(function() {
		$(this).empty();
		$(this).append(decodeArticleContent($(this).data("article-key")));
	});
}

function goNext() {
	if($("#page-form").valid()) {
		apiService.doSC002().then(function() {
			location.href = 'step4.html';
		});
	}
}

function doSubmit() {
	var hasSubmit = localStorage.getItem(LSKey.HAS_APPLICATION_SUBMIT);

	_paq.push(['trackEvent', '雲端櫃台-線上申請信用卡(手機版)-個人資料保護法、費率及用卡須知', '送出申請', '']);

	if(hasSubmit === "Y") {
		openResultModal();
	} else if(hasSubmit === "N") {
		showLoadingView();
		sendApplicationInfo();
	}
}

function sendApplicationInfo() {
	$.Deferred().resolve().promise()
	.then(function() {
		return apiService.doCM008();
	})
	.then(function(rsDataJSON) {
		// 組成xml檔名
		var CM008RsDataObj = JSON.parse(rsDataJSON);
		CM010RqDataObj.xmlName = '' + CM008RsDataObj.preDate + CM008RsDataObj.serNo + CommonConstant.UPLOAD_XML_POSTFIX_WITH_FILE_EXT;

		return doCM010();
	});
}

function doCM010() {
	var failCount = (localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) ? parseInt(localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) : 0;
	
	CM010RqDataObj.toPDF = "0";
	apiService.doCM010(JSON.stringify(CM010RqDataObj)).then(
	function(rsDataJSON) {
		// doneCallback
		localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
		localStorage.setItem(LSKey.HAS_APPLICATION_SUBMIT, "Y");
		hideLoadingView();
		openResultModal();
	},
	function(xhrStatus) {
		// failCallback
		failCount++;
		localStorage.setItem(LSKey.APPLICATION_FAIL_COUNT, failCount);

		if(failCount === 1) {
			console.log("failCount === 1, before resend CM010, timestamp: " + new Date().getTime());
			// 進行一次retry，重新發送CM010
			setTimeout(function() {
				console.log("resend CM010, timestamp: " + new Date().getTime());
				doCM010();
			}, 2000);
		} else if(failCount > 1) {
			hideLoadingView();
			showErrorPage(apiService.errorMsg.CM010_HTTP_STATUS_503_AND_0 + "(Err Code：" + xhrStatus + ")");
		}
	});
}

function openResultModal() {
	var nowDate = new Date();
	var nowDateY = nowDate.getFullYear();
	var nowDateM = nowDate.getMonth() + 1;
	var nowDateD = nowDate.getDate();
	$("span[data-name='applyDate']").text(nowDateY + "年" + nowDateM + "月" + nowDateD + "日");

	var modal = $("#applicationFinishModal");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			height : modal.height() + 'px',
			top : '45%',
			left : '50%',
			width : '80%',
			maxWidth : '800px',
			transform : 'translate(-50%,-50%)',
			border: 'none',
			'-webkit-border-radius': '5px',
			'-moz-border-radius': '5px',
			'border-radius': '5px',
			backgroundColor: 'white'
		}
	});
}

function doFinish() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

function showResultPage() {
	apiService.doSC002().then(function() {
		location.href = "resultPage.html";
	});
}

function initValidate() {
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		messages: {
			article_C2: {
				required: "請先閱讀個人資料保護法告知義務"
			},
			article_C3: {
				required: "請先閱讀信用卡循環信用利率及各項費用計算說明"
			},
			article_C4: {
				required: "請先閱讀用卡須知"
			},
			article_F3: {
				required: "請同意本項業務契約，如不同意則無法申請信用卡"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(this).removeClass('is-invalid');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,element){
					$(errorList[index].element).addClass('is-invalid');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}