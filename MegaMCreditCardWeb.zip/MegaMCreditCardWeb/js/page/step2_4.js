$(window).bind("pageshow", function(event) {
	if(checkUserAgent() && checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		setProcessImg(CM010RqDataObj.isOrigin);

		var queryCodeJSON = localStorage.getItem(LSKey.QUERY_CODE);
		queryCodeObj = (queryCodeJSON) ? JSON.parse(queryCodeJSON) : "";

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	//預設勾選
	$("input[name='mAcceptDm']").prop("checked", true);


	if(queryCodeObj && queryCodeObj.e) {
		$("input[name='cIntrCode']").val(queryCodeObj.e);
		$("input[name='cIntrCode']").prop("disabled", true);
	} else {
		$("input[name='cIntrCode']").val(CM010RqDataObj.cIntrCode);
	}
}

function doSubmit() {
	if($("input[name='mAcceptDm']:checked").length > 0) {
		CM010RqDataObj.mAcceptDm = "1";
	} else {
		CM010RqDataObj.mAcceptDm = "0";
	}

	if(queryCodeObj && queryCodeObj.e) {
		// e值帶入的無須特別處理
		CM010RqDataObj.cIntrCode = queryCodeObj.e;
	} else {
		// 使用者自行輸入的，長度不足6碼，前面補零至6碼
		var cIntrCode = $("input[name='cIntrCode']").val();
		if(cIntrCode) {
			CM010RqDataObj.cIntrCode = appendPrefixZero(cIntrCode, 6);
		}
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));

	apiService.doSC002().then(function() {
		location.href = "step3_1.html";
	});
}

function initValidate() {
	// 行員代號只能輸入英數字
	$.validator.addMethod('isIntrCode', function(value){
		if(value) {
			return /^[A-Za-z0-9]+$/gi.test(value);
		} else {
			return true;
		}
	});
	
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cIntrCode: {
				isIntrCode: true
			}
		},
		messages: {
			cIntrCode: {
				isIntrCode: "限輸入英數字"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = errorList.findIndex(function(errElement) {
						return errElement.element.name === element.name;
					});
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showToast(errorList[0].message);
			}
		}
	});
}
