$(document).ready(function(){
	if(checkUserAgent() && checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.VR012_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		VR012RqDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RQ_DATA));
		VR011RqDataObj = new VR011RqData();
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl();
		PageNavigationHandler.backControl();
		doSC001();
		init();
		initValidate();
	}
});

function init() {
	var articleLoaders = $(".articleLoader");
	articleLoaders.each(function() {
		$(this).empty();
		$(this).append(decodeArticleContent($(this).data("article-key")));
	});

	apiService.doCM006().then(function(rsDataJSON) {
		var CM006RsDataObj = JSON.parse(rsDataJSON);
		var itemsList = CM006RsDataObj.items;
		itemsList.forEach(function(items) {
			$("select[name='bank']").append("<option value='" + items.bankCode + "'>" + items.bankName + "</option>");
		});
	});
	
	var nowDate = new Date();
	var nowDateYear = nowDate.getFullYear();	// 西元年
	var nowDateCYear = nowDateYear - 1911;		// 民國年
	
	initBirthdayInput();
	initDueDateSelectList(nowDateYear);
	initCreditCardInput();
	setCheckBoxExclusive("validationAgreement");
}

function doSC001() {
	apiService.doSC001().then(function(rsDataJSON) {
		var SC001RsDataObj = JSON.parse(rsDataJSON);
		localStorage.setItem(LSKey.TOKEN_ID, SC001RsDataObj.tokenID);
		localStorage.setItem(LSKey.TOKEN_TIME, SC001RsDataObj.tokenTime);
		localStorage.setItem(LSKey.TIMEOUT_ALERT_TIME, SC001RsDataObj.timeoutAlertTime);
		localStorage.setItem(LSKey.AES_KEY, SC001RsDataObj.aesKey);

		$("img[data-name='gOTP']").attr("src", SC001RsDataObj.gOTP);

		startTimer();
	});
}

function initBirthdaySelectList(nowDateCYear) {
	var birthdayYearList = $("select[name='birthday_Y']");
	for(var i = nowDateCYear - 100; i < nowDateCYear - 19; i++) {
		birthdayYearList.append("<option value='" + i + "'>" + i + "</option>");
	}

	birthdayYearList.focus(function() {
		if($(this).data("focused") !==  true) {
			birthdayYearList.children("option[value='" + (nowDateCYear - 30) + "']").prop('selected', true);
		}
	});

	birthdayYearList.blur(function() {
		$(this).data('focused', false); 
	});

	for(var i = 1; i <= 12; i++) {
		$("select[name='birthday_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	for(var i = 1; i <= 31; i++) {
		$("select[name='birthday_D']").append("<option value='" + i + "'>" + i + "</option>");
	}
}

function initDueDateSelectList(nowDateYear) {
	for(var i = 1; i <= 12; i++) {
		$("select[name='dueDate_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	var dueDateYearList = $("select[name='dueDate_Y']");
	for(var i = nowDateYear; i <= nowDateYear + 10; i++) {
		var year = nowDateYear + i;
		dueDateYearList.append("<option value='" + i + "'>" + i + "</option>");
	}

	dueDateYearList.focus(function() {
		if($(this).data("focused") !==  true) {
			$(this).data("focused", true);  
			dueDateYearList.children("option[value='" + nowDateYear + "']").prop('selected', true);
		}
	});

	dueDateYearList.blur(function() {
		$(this).data('focused', false); 
	});
}

function initCreditCardInput() {
	$("input[name='creditCard_1']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_2']").focus();
		}
	});

	$("input[name='creditCard_2']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_3']").focus();
		}
	});

	$("input[name='creditCard_3']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_4']").focus();
		}
	});
}
function initBirthdayInput() {
	$("input[name='birthday_Y']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length == parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='birthday_M']").focus();
		}
	});
	$("input[name='birthday_M']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length == parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='birthday_D']").focus();
		}
	});
	$("input[name='birthday_M']").on("focusout", function(e){
		e.preventDefault();
		if($(this).val().length == 1 && /\b[1-9]\b/gm.test($(this).val()) ) {			
			$(this).val(appendPrefixZero($(this).val(), 2));
		}
	});
	$("input[name='birthday_D']").on("focusout", function(e){
		e.preventDefault();
		if($(this).val().length == 1 && /\b[1-9]\b/gm.test($(this).val()) ) {			
			$(this).val(appendPrefixZero($(this).val(), 2));
		}
	});

}
function doSubmit() {
	updateVR011RqDataObj();
	
	var VR011RqDataJSON = JSON.stringify(VR011RqDataObj);
	
	apiService.doVR011(VR011RqDataJSON).then(function(rsDataJSON) {
		var VR011RsDataObj = JSON.parse(rsDataJSON);
		
		VR012RqDataObj.uuid = VR011RsDataObj.uuid;
		VR012RqDataObj.primID = VR011RqDataObj.primID;
		VR012RqDataObj.birthDay = VR011RqDataObj.birthDay;
		
		CM010RqDataObj.cPrimId = VR011RqDataObj.primID;
		CM010RqDataObj.cAccount = VR011RqDataObj.bank + VR011RqDataObj.account;
		CM010RqDataObj.cPrimCellulaNo1 = VR011RqDataObj.phoneNo;
		CM010RqDataObj.isOrigin = CommonConstant.IS_USERVRFY;
		
		localStorage.setItem(LSKey.VR012_RQ_DATA, JSON.stringify(VR012RqDataObj));
		localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
		
		location.href = "step1b.html";
	});
}

function updateVR011RqDataObj() {
	var birthday_Y = appendPrefixZero($("input[name='birthday_Y']").val(), 3);
	var birthday_E = appendPrefixZero((parseInt($("input[name='birthday_Y']").val()) + 1911), 4);
	var birthday_M = appendPrefixZero($("input[name='birthday_M']").val(), 2);
	var birthday_D = appendPrefixZero($("input[name='birthday_D']").val(), 2);

	VR011RqDataObj.bank = $("select[name='bank']").val();
	VR011RqDataObj.account = $("input[name='account']").val();
	VR011RqDataObj.primID = $("input[name='primID']").val();
	VR011RqDataObj.phoneNo = $("input[name='phoneNo']").val();
	VR011RqDataObj.otp = $("input[name='otp']").val();
	VR011RqDataObj.birthDay = birthday_Y + birthday_M + birthday_D;
	
	CM010RqDataObj.cPrimBirthday = birthday_Y + birthday_M + birthday_D;
}

function initValidate() {
	/** 身分證檢核 */
	$.validator.addMethod('rocID', function(value,element) {
		return /^[a-z]{1,1}[1-2]{1,1}\d{8,8}$/gi.test(value);
	},'請輸入正確的身分證字號');

	/** 檢核正卡申請人需年滿20歲 */
	$.validator.addMethod('legalAdulthood', function(value,element) {
		var today = new Date();
		var rocYear = today.getFullYear() - 1911;
		var birthday_Y = $('[name=birthday_Y]').val() ? (parseInt($('[name=birthday_Y]').val(),10) + 1911) : today.getFullYear();
		var birthday_M = $('[name=birthday_M]').val() || '01';
		var birthday_D = $('[name=birthday_D]').val() || '01'; 
		var birthday = new Date(birthday_Y+'/'+birthday_M+'/'+birthday_D);
		var age = today.getFullYear() - birthday.getFullYear();
		birthday.setFullYear(today.getFullYear());
		if(today < birthday) age --;
		return age >= 20;
	},'正卡申請人須年滿20歲');
	/** Validation */
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			primID: {
				required: true,
				rocID: true
			},
			birthday_Y: {
				legalAdulthood: {
					depends: function(element){ return element.value; }
				}
			},
			birthday_M: {
				legalAdulthood: {
					depends: function(element){ return element.value; }
				}
			},
			birthday_D: {
				legalAdulthood: {
					depends: function(element){ return element.value; }
				}
			},
			bank: "digits",
			account: "digits",
			phoneNo: "digits"
		},
		messages: {
			primID: {
				required: "請輸入身分證字號"
			},
			birthday_Y: {
				required: "請輸入生日-年"
			},
			birthday_M: {
				required: "請輸入生日-月"
			},
			birthday_D: {
				required: "請輸入生日-日"
			},
			bank: {
				required: "請輸入完整原存行",
				digits: "僅限輸入數字"
			},
			account: {
				required: "請輸入完整存款帳戶",
				digits: "僅限輸入數字"
			},
			phoneNo: {
				required: "請輸入完整手機號碼",
				digits: "僅限輸入數字"
			},
			otp: {
				required: "請輸入圖形驗證碼"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = errorList.findIndex(function(errElement) {
						return errElement.element.name === element.name;
					});
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showToast(errorList[0].message);
			}
		}
	});
}
