$(window).bind("pageshow", function(event) {
	if(checkUserAgent() && checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		CardFriendInfoObj = JSON.parse(localStorage.getItem(LSKey.CARD_FRIEND_INFO));
		VR012RsDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RS_DATA));

		apiService = new ApiService();

		targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	var cPrimCellulaNo1 = (CM010RqDataObj.cPrimCellulaNo1) ? CM010RqDataObj.cPrimCellulaNo1 : "";
	var cPrimEmail = (CM010RqDataObj.cPrimEmail) ? CM010RqDataObj.cPrimEmail : "";

	$("input[name='cPrimCellulaNo1']").val(cPrimCellulaNo1);
	$("input[name='cPrimEmail']").val(cPrimEmail);

	// 本行手機號碼，不可修改
	if((CardFriendInfoObj && CardFriendInfoObj.phoneNo) || (VR012RsDataObj && VR012RsDataObj.phoneNo)) {
		$("input[name='cPrimCellulaNo1']").prop('disabled', true);
	}

	initEbillArticle();
}

function initEbillArticle() {
	// 電子帳單同意條款
	if(targetCard.eBill === "Y") {
		var mBillDesc = "申請" + targetCard.cardName + "者，其帳單均預設為以電子郵件方式寄送。";
		$("#mBillDesc_isEbill").text(mBillDesc);
		$("#mBillDesc_isEbill").show();
	} else {
		setCheckBoxExclusive("mBillByMail");

		if(CM010RqDataObj.mBillByMail && CM010RqDataObj.mBillByMail === "0") {
			$("#mBillByMail_Y").prop("checked", false);
			$("#mBillByMail_N").prop("checked", true);
		} else {
			$("#mBillByMail_Y").prop("checked", true);
			$("#mBillByMail_N").prop("checked", false);
		}
		$("#mBillDesc_notEbill").show();
	}
}

function doSubmit() {
	CM010RqDataObj.cPrimCellulaNo1 = $("input[name='cPrimCellulaNo1']").val();
	CM010RqDataObj.cPrimEmail = $("input[name='cPrimEmail']").val();

	// 當eBill為Y時，其帳單預設為以電子郵件方式寄送
	if(targetCard.eBill === "Y") {
		CM010RqDataObj.mBillDesc = $("#mBillDesc_isEbill").text();
		CM010RqDataObj.mBillByMail = "1";
	} else {
		CM010RqDataObj.mBillDesc = "";
		
		if($("#mBillByMail_N:checked").length > 0) {
			CM010RqDataObj.mBillByMail = "0";
		} else {
			CM010RqDataObj.mBillByMail = "1";
		}
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));

	apiService.doSC002().then(function() {
		location.href = "step2_4.html";
	});
}

function initValidate() {
	//email格式：須包含一個「＠」與一個（含）以上的「.」
	$.validator.addMethod('strictEmail', function(value){
		return isEmailValid(value);
	});
	//email為必填
	var isEmailRequired = function() {
		return targetCard.eBill === "Y" || $("#mBillByMail_Y:checked").length > 0;
	};

	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cPrimCellulaNo1: {
				digits: true
			},
			cPrimEmail: {
				required: {
					depends: isEmailRequired
				},
				strictEmail: {
					depends: function() {
						return ($("input[name='cPrimEmail']").val()).length > 0;
					}
				}
			},
			mBillByMail: {
				required: {
					depends: function() {
						return targetCard.eBill !== "Y";
					}
				}
			}
		},
		messages: {
			cPrimCellulaNo1: {
				required: "請輸入行動電話",
				digits: "僅限輸入數字"
			},
			cPrimEmail: {
				required: "請輸入E-mail",
				strictEmail: "請輸入正確的E-mail格式"
			},
			mBillByMail: {
				required: "請進行電子帳單同意選擇"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = errorList.findIndex(function(errElement) {
						return errElement.element.name === element.name;
					});
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showToast(errorList[0].message);
			}
		}
	});
}