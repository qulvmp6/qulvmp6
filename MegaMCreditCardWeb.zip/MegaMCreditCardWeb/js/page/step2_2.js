 $.pageshow = function (fn) {
            if (typeof window.onpageshow == "undefined")
                $(document).ready(fn);
            else
                $(window).bind("pageshow", fn);
        };

$.pageshow(function(event) {
	if(checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.CM002_RS_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		CM002RsDataObj = JSON.parse(localStorage.getItem(LSKey.CM002_RS_DATA));
		apiService = new ApiService();

		targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {	
	initSelectList();
	initFormControl();
	restoreInputForm();
	initEbillArticle();
}

function initEbillArticle() {
	// 電子帳單同意條款
	if(targetCard.eBill === "Y") {
		var mBillDesc = "申請" + targetCard.cardName + "者，其帳單均預設為以電子郵件方式寄送。";
		$("#mBillDesc_isEbill").text(mBillDesc);
		$("#mBillDesc_isEbill").show();
	} else {
		setCheckBoxExclusive("mBillByMail");

		if(CM010RqDataObj.mBillByMail && CM010RqDataObj.mBillByMail === "0") {
			$("#mBillByMail_Y").prop("checked", false);
			$("#mBillByMail_N").prop("checked", true);
		} else {
			$("#mBillByMail_Y").prop("checked", true);
			$("#mBillByMail_N").prop("checked", false);
		}
		$("#mBillDesc_notEbill").show();
	}
}



function initSelectList() {
	addrZoneMap = {};

	var addrZoneList = CM002RsDataObj.addrZone;
	addrZoneList.forEach(function(addrZone) {
		addrZoneMap[addrZone.city] =  addrZone.dists;

		$("select[name='cPrimAddr2City']").append("<option value='" + addrZone.city + "'>" + addrZone.city + "</option>");
		$("select[name='cPrimAddr1City']").append("<option value='" + addrZone.city + "'>" + addrZone.city + "</option>");
	});

	$("select[name='cPrimAddr2City']").change(function() {
		updateAddrZipSelectList($("select[name='cPrimAddr2Zip']"), $(this).val());
	})
	$("select[name='cPrimAddr1City']").change(function() {
		updateAddrZipSelectList($("select[name='cPrimAddr1Zip']"), $(this).val());
	})

	var telZoneNumList = CM002RsDataObj.telZoneNum;
	telZoneNumList.forEach(function(telZoneNum) {
		$("select[name='cPrimHomeTelNo1a']").append("<option value='" + telZoneNum.key + "'>" + telZoneNum.value + "</option>");
		$("select[name='cPrimHomeTelNo2a']").append("<option value='" + telZoneNum.key + "'>" + telZoneNum.value + "</option>");
	});

	var addrCondList = CM002RsDataObj.addrCond;
	addrCondList.forEach(function(addrCond) {
		$("select[name='mPrimAddr1Cond']").append("<option value='" + addrCond.key + "'>" + addrCond.value + "</option>");
	});
}

function updateAddrZipSelectList(jqTarget, city) {
	jqTarget.empty();
	jqTarget.append("<option value=''>鄉鎮市區</option>");

	if(city) {
		var dists = addrZoneMap[city];
		dists.forEach(function(distInfo) {
			jqTarget.append("<option value='" + distInfo.postalCode + "'>" + distInfo.dist + "</option>");
		});
	}
}

function initFormControl() {
	$("input[name='sameAsAddr2']").change(function() {
		if(this.checked) {
			$("#cPrimAddr1Group").hide();
		} else {
			$("#cPrimAddr1Group").show();
		}
	});

	$("input[name='sameAsTel1']").change(function() {
		if(this.checked) {
			$("#cPrimTel2Group").hide();
		} else {
			$("#cPrimTel2Group").show();
		}
	});
	
	$("input[name='cPrimHomeTelNo1b']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='cPrimHomeTelNo1c']").focus();
		}
	});

	$("input[name='cPrimHomeTelNo2b']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='cPrimHomeTelNo2c']").focus();
		}
	});
	
	if (CM010RqDataObj.isOrigin === CommonConstant.IS_USERVRFY) {
		$("input[name='cPrimCellulaNo1']").val(CM010RqDataObj.cPrimCellulaNo1);
	}
}

function restoreInputForm() {
	updateAddrZipSelectList($("select[name='cPrimAddr2Zip']"), localStorage.getItem(LSKey.ADDR2_CITY));
	$("select[name='cPrimAddr2City']").val(localStorage.getItem(LSKey.ADDR2_CITY));
	$("select[name='cPrimAddr2Zip']").val(CM010RqDataObj.cPrimAddr2Zip);
	$("input[name='cPrimAddr2']").val(CM010RqDataObj.cPrimAddr2);

	if(CM010RqDataObj.cPrimAddr2Zip === CM010RqDataObj.cPrimAddr1Zip && 
			CM010RqDataObj.cPrimAddr2 === CM010RqDataObj.cPrimAddr1) {
		if(CM010RqDataObj.cPrimAddr2Zip && CM010RqDataObj.cPrimAddr2) {
			$("input[name='sameAsAddr2']").prop('checked', true);
			$("#cPrimAddr1Group").hide();
		} else {
			$("input[name='sameAsAddr2']").prop('checked', false);
			$("#cPrimAddr1Group").show();
		}
		$("select[name='cPrimAddr1City']").val("");
		$("select[name='cPrimAddr1Zip']").val("");
		$("input[name='cPrimAddr1']").val("");
	} else {
		updateAddrZipSelectList($("select[name='cPrimAddr1Zip']"), localStorage.getItem(LSKey.ADDR1_CITY));
		$("select[name='cPrimAddr1City']").val(localStorage.getItem(LSKey.ADDR1_CITY));
		$("select[name='cPrimAddr1Zip']").val(CM010RqDataObj.cPrimAddr1Zip);
		$("input[name='cPrimAddr1']").val(CM010RqDataObj.cPrimAddr1);
	}

	$("select[name='cPrimHomeTelNo1a']").val(CM010RqDataObj.cPrimHomeTelNo1a);
	$("input[name='cPrimHomeTelNo1b']").val(CM010RqDataObj.cPrimHomeTelNo1b);
	$("input[name='cPrimHomeTelNo1c']").val(CM010RqDataObj.cPrimHomeTelNo1c);

	if (CM010RqDataObj.cPrimHomeTelNo2a === CM010RqDataObj.cPrimHomeTelNo1a && 
			CM010RqDataObj.cPrimHomeTelNo2b === CM010RqDataObj.cPrimHomeTelNo1b && 
			CM010RqDataObj.cPrimHomeTelNo2c === CM010RqDataObj.cPrimHomeTelNo1c) {
		if(CM010RqDataObj.cPrimHomeTelNo2a || CM010RqDataObj.cPrimHomeTelNo2b || CM010RqDataObj.cPrimHomeTelNo2c) {
			$("input[name='sameAsTel1']").prop('checked', true);
			$("#cPrimTel2Group").hide();
		} else {
			$("input[name='sameAsTel1']").prop('checked', false);
			$("#cPrimTel2Group").show();
		}
		$("select[name='cPrimHomeTelNo2a']").val("");
		$("select[name='cPrimHomeTelNo2b']").val("");
		$("input[name='cPrimHomeTelNo2c']").val("");
	} else {
		$("select[name='cPrimHomeTelNo2a']").val(CM010RqDataObj.cPrimHomeTelNo2a);
		$("input[name='cPrimHomeTelNo2b']").val(CM010RqDataObj.cPrimHomeTelNo2b);
		$("input[name='cPrimHomeTelNo2c']").val(CM010RqDataObj.cPrimHomeTelNo2c);
	}

	$("input[name='cPrimCellulaNo1']").val(CM010RqDataObj.cPrimCellulaNo1);

	$("select[name='mPrimAddr1Cond']").val(CM010RqDataObj.mPrimAddr1Cond);

	$("input[name='cPrimAddr1LiveYear']").val(CM010RqDataObj.cPrimAddr1LiveYear);

	$("input[name='cPrimEmail']").val(CM010RqDataObj.cPrimEmail);
}

function doSubmit() {
	updateCM010RqDataObj();

	localStorage.setItem(LSKey.ADDR1_CITY, $("select[name='cPrimAddr1City']").val());
	localStorage.setItem(LSKey.ADDR2_CITY, $("select[name='cPrimAddr2City']").val());

	apiService.doSC002().then(function() {
		location.href = "step2_3.html";
	});
}

function updateCM010RqDataObj() {
	CM010RqDataObj.cPrimAddr2Zip = $("select[name='cPrimAddr2Zip']").val();
	CM010RqDataObj.cPrimAddr2 = $("input[name='cPrimAddr2']").val();

	if($("input[name='sameAsAddr2']:checked").length > 0) {
		CM010RqDataObj.cPrimAddr1Zip = $("select[name='cPrimAddr2Zip']").val();
		CM010RqDataObj.cPrimAddr1 = $("input[name='cPrimAddr2']").val();
	} else {
		CM010RqDataObj.cPrimAddr1Zip = $("select[name='cPrimAddr1Zip']").val();
		CM010RqDataObj.cPrimAddr1 = $("input[name='cPrimAddr1']").val();
	}

	CM010RqDataObj.cPrimHomeTelNo1a = $("select[name='cPrimHomeTelNo1a'] option:selected").val();
	CM010RqDataObj.cPrimHomeTelNo1b = $("input[name='cPrimHomeTelNo1b']").val();
	CM010RqDataObj.cPrimHomeTelNo1c = $("input[name='cPrimHomeTelNo1c']").val();
	
	if ($("input[name='sameAsTel1']:checked").length > 0) {
		CM010RqDataObj.cPrimHomeTelNo2a = $("select[name='cPrimHomeTelNo1a'] option:selected").val();
		CM010RqDataObj.cPrimHomeTelNo2b = $("input[name='cPrimHomeTelNo1b']").val();
		CM010RqDataObj.cPrimHomeTelNo2c = $("input[name='cPrimHomeTelNo1c']").val();
	} else {
		CM010RqDataObj.cPrimHomeTelNo2a = $("select[name='cPrimHomeTelNo2a'] option:selected").val();
		CM010RqDataObj.cPrimHomeTelNo2b = $("input[name='cPrimHomeTelNo2b']").val();
		CM010RqDataObj.cPrimHomeTelNo2c = $("input[name='cPrimHomeTelNo2c']").val();
	}

	CM010RqDataObj.cPrimCellulaNo1 = $("input[name='cPrimCellulaNo1']").val();
	CM010RqDataObj.mPrimAddr1Cond = $("select[name='mPrimAddr1Cond']").val();
	CM010RqDataObj.cPrimAddr1LiveYear = $("input[name='cPrimAddr1LiveYear']").val();
	CM010RqDataObj.cPrimEmail = $("input[name='cPrimEmail']").val();

	// 當eBill為Y時，其帳單預設為以電子郵件方式寄送
	if(targetCard.eBill === "Y") {
		CM010RqDataObj.mBillDesc = $("#mBillDesc_isEbill").text();
		CM010RqDataObj.mBillByMail = "1";
	} else {
		CM010RqDataObj.mBillDesc = "";
		
		if($("#mBillByMail_N:checked").length > 0) {
			CM010RqDataObj.mBillByMail = "0";
		} else {
			CM010RqDataObj.mBillByMail = "1";
		}
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
}

function initValidate() {
	//同戶籍地址
	var differentFromRegisteredResidence = function() {
		return !$('#sameAsAddr2').prop('checked');
	};
	//同同戶籍電話
	var differentFromRegisteredTelResidence = function() {
		return !$('#sameAsTel1').prop('checked');
	};
	//email格式：須包含一個「＠」與一個（含）以上的「.」
	$.validator.addMethod('strictEmail', function(value){
		return isEmailValid(value);
	});

	// 地址不可以有「/」、「$」、「@」、「「」、「」」、「。」、「、」、「?」、「？」、「!」、「！」、「.」、「'」、「,」、「，」
	$.validator.addMethod('strictAddr', function(value){
		return /^[^/$@「」。、?？!！.',，]+$/g.test(value);
	});

	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cPrimAddr2: {
				strictAddr: true
			},
			cPrimAddr1City: {
				required: {
					depends: differentFromRegisteredResidence
				}
			},
			cPrimAddr1Zip: {
				required: {
					depends: differentFromRegisteredResidence
				}
			},
			cPrimAddr1: {
				required: {
					depends: differentFromRegisteredResidence
				},
				strictAddr: {
					depends: differentFromRegisteredResidence
				}
			},
			cPrimHomeTelNo1b: {
				digits: true
			},
			cPrimHomeTelNo1c: {
				digits: true
			},
			cPrimHomeTelNo2b: {
				digits: true
			},
			cPrimHomeTelNo2c: {
				digits: true
			},
			cPrimCellulaNo1: {
				digits: true
			},
			cPrimAddr1LiveYear: {
				digits: true
			},
			cPrimEmail: {
				strictEmail: {
					depends: function() {
						return ($("input[name='cPrimEmail']").val()).length > 0;
					}
				}
			},
			mBillByMail: {
				required: {
					depends: function() {
						return targetCard.eBill !== "Y";
					}
				}
			}
		},
		messages: {
			cPrimAddr2City: {
				required: "請輸入完整戶籍地址"
			},
			cPrimAddr2Zip: {
				required: "請輸入完整戶籍地址"
			},
			cPrimAddr2: {
				required: "請輸入完整戶籍地址",
				strictAddr: "地址不可帶有特殊符號"
			},
			cPrimAddr1City: {
				required: "請輸入完整居住地址"
			},
			cPrimAddr1Zip: {
				required: "請輸入完整居住地址"
			},
			cPrimAddr1: {
				required: "請輸入完整居住地址",
				strictAddr: "地址不可帶有特殊符號"
			},
			cPrimHomeTelNo1b: {
				digits: "僅限輸入數字"
			},
			cPrimHomeTelNo1c: {
				digits: "僅限輸入數字"
			},
			cPrimHomeTelNo2b: {
				digits: "僅限輸入數字"
			},
			cPrimHomeTelNo2c: {
				digits: "僅限輸入數字"
			},
			cPrimCellulaNo1: {
				required: "請輸入行動電話",
				digits: "僅限輸入數字"
			},
			cPrimAddr1LiveYear: {
				digits: "僅限輸入數字"
			},
			cPrimEmail: {
				required: "請輸入E-mail",
				strictEmail: "請輸入正確E-mail格式"
			},
			mBillByMail: {
				required: "請選擇是否同意電子帳單"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}