var countdownInterval = null;

$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.SMS_OTP_INFO])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		SmsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl();
		PageNavigationHandler.backControl();

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	if(SmsOtpInfoObj) {
		$('#maskPhone').text(SmsOtpInfoObj.maskPhone);
		$('#smsOtpCountdownSec').text(SmsOtpInfoObj.smsOtpCountdownSec);

		if(SmsOtpInfoObj.smsOtpCountdownSec && SmsOtpInfoObj.smsOtpCountdownSec > 0) {
			$('#sendOtpBtn').prop('disabled', true);
			$('#nextBtn').prop('disabled', false);

			doSmsOtpCountdown();
		} else {
			$('#sendOtpBtn').prop('disabled', false);
			$('#nextBtn').prop('disabled', true);
		}

		$("#sendOtpBtn").bind("click", function() {
			return sendSmsOtp();
		});
	}
}

// 發送簡訊OTP
function sendSmsOtp() {
	$.Deferred().resolve().promise()
	.then(function() {
		var VR003RqDataObj = new VR003RqData();
		VR003RqDataObj.custID = CM010RqDataObj.cPrimId;
		VR003RqDataObj.birthday = CM010RqDataObj.cPrimBirthday;

		var VR003RqDataJSON = JSON.stringify(VR003RqDataObj);
		return apiService.doVR003(VR003RqDataJSON);
	})
	.then(function(rsDataJSON) {
		// 簡訊OTP發送成功，更新畫面資訊、清空簡訊密碼輸入框，並啟動倒數
		var VR003RsDataObj = JSON.parse(rsDataJSON);
		var countdownSec = CommonConstant.DEFAULT_SMS_OTP_COUNTDOWN_SEC;
		var smsOtpInfoObj = {
			seqNo: VR003RsDataObj.seqNo,
			maskPhone: VR003RsDataObj.maskPhone,
			smsOtpCountdownSec: countdownSec
		};

		localStorage.setItem(LSKey.SMS_OTP_INFO, JSON.stringify(smsOtpInfoObj));

		$('#maskPhone').text(VR003RsDataObj.maskPhone);
		$('#smsOtpCountdownSec').text(countdownSec);
		$('input[name="otpPwd"]').val('');

		$('#sendOtpBtn').prop('disabled', true);
		$('#nextBtn').prop('disabled', false);

		doSmsOtpCountdown();
	});
}

// 簡訊OTP有效秒數倒數
function doSmsOtpCountdown() {
	countdownInterval = setInterval(function() {
		var smsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));
		var countdownSec = smsOtpInfoObj.smsOtpCountdownSec;

		if(countdownSec > 0) {
			countdownSec--;
			$("#smsOtpCountdownSec").text(countdownSec);

			smsOtpInfoObj.smsOtpCountdownSec = countdownSec;
			localStorage.setItem(LSKey.SMS_OTP_INFO, JSON.stringify(smsOtpInfoObj));
		} else {
			clearInterval(countdownInterval);

			$('#sendOtpBtn').prop('disabled', false);
			$('#nextBtn').prop('disabled', true);
		}
	}, 1000);
}

function doSubmit() {
	$.Deferred().resolve().promise()
	.then(function() {
		var smsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));
		var VR004RqDataObj = new VR004RqData();
		VR004RqDataObj.custID = CM010RqDataObj.cPrimId;
		VR004RqDataObj.birthday = CM010RqDataObj.cPrimBirthday;
		VR004RqDataObj.seqNo = smsOtpInfoObj.seqNo;
		VR004RqDataObj.otpCode = $('input[name="otpPwd"]').val();

		var VR004RqDataJSON = JSON.stringify(VR004RqDataObj);
		return apiService.doVR004(VR004RqDataJSON);
	})
	.then(function(response) {
		var returnCode = response.responseHeader.returnCode;
		if(returnCode === apiService.returnCode.SUCCESS) {
			var rsDataJSON = response.responseBody.data;
			var VR004RsDataObj = JSON.parse(rsDataJSON);

			CM010RqDataObj.isOrigin = CommonConstant.IS_ORIGIN;
			CM010RqDataObj.cPrimChName = VR004RsDataObj.primChName;
			CM010RqDataObj.cPrimCellulaNo1 = VR004RsDataObj.phoneNo;
			CM010RqDataObj.cPrimEmail = VR004RsDataObj.email;

			var cardFriendInfoObj = {
				primChName: VR004RsDataObj.primChName,
				cardFlag: VR004RsDataObj.cardFlag,
				billAddr: VR004RsDataObj.billAddr,
				autoPayIndicator: VR004RsDataObj.autoPayIndicator,
				autoPayAcctBank: VR004RsDataObj.autoPayAcctBank,
				autoPayAcctNo: VR004RsDataObj.autoPayAcctNo,
				phoneNo: VR004RsDataObj.phoneNo,
				email: VR004RsDataObj.email
			};

			localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
			localStorage.setItem(LSKey.CARD_FRIEND_INFO, JSON.stringify(cardFriendInfoObj));

			localStorage.removeItem(LSKey.SMS_OTP_INFO);

			location.href = "step2_1.html";
		} else if(returnCode === apiService.returnCode.SMS_OTP_PWD_INVALID) {
			// 簡訊驗證碼輸入有誤，驗證失敗，以toast提示
			showErrAlert(response.responseHeader.returnMsg);
		} else {
			// 其他錯誤，導錯誤頁
			showErrorPage(response.responseHeader.returnMsg);
		}
	});
}

function initValidate() {
	/** Validation */
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			otpPwd: {
				required: true,
				digits: true
			}
		},
		messages: {
			otpPwd: {
				required: "請輸入簡訊密碼",
				digits: "僅限輸入數字"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showErrAlert(errorList);
			}
		}
	});
}

