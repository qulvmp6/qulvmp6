var hasNotified = false;

$(document).ready(function(){
	if(checkLocalStorage([LSKey.VR012_RQ_DATA, LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		VR012RqDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RQ_DATA));
		
		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();
		init();
		resize();
	}
});

function init() {
	var url = iFrameUrl()+"&UUID="+VR012RqDataObj.uuid;
	$("#mainframe").prop("src", url);
}

window.addEventListener("message", doSubmit, false);
function doSubmit(event) {
	var VR012RqDataJSON = JSON.stringify(VR012RqDataObj);
	var apiService = new ApiService();
	
	localStorage.setItem(LSKey.VR012_RQ_DATA, VR012RqDataJSON);
	apiService.doVR012(VR012RqDataJSON).then(function(rsDataJSON) {
		var VR012RsDataObj = JSON.parse(rsDataJSON);
		if(VR012RsDataObj.isCardFriend == "Y"){
			CM010RqDataObj.isOrigin = CommonConstant.IS_ORIGIN;
			CM010RqDataObj.cPrimChName = VR012RsDataObj.primChName;
			CM010RqDataObj.cPrimCellulaNo1 = VR012RsDataObj.phoneNo;
			CM010RqDataObj.cPrimEmail = VR012RsDataObj.email;
			localStorage.setItem(LSKey.CM010_RQ_DATA,JSON.stringify(CM010RqDataObj));
			localStorage.setItem(LSKey.VR012_RS_DATA,JSON.stringify(VR012RsDataObj));
			localStorage.setItem(LSKey.CURRENT_HTML, "otpVerify.html");
		}		
		location.href = "step2_1.html";
	});
}

var resize = function () {
    parent.document.getElementById("mainframe").height = document.body.scrollHeight; //將子頁面高度傳到父頁面框架
}
