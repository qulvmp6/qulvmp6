var hasNotified = false;

$(document).ready(function(){
	if(checkUserAgent() && checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();

		init();

		startTimer();
	}
});

function init() {
//	$(".c-article-item__title").bind("click", function() {
//		showArticle(decodeArticleContent($(this).data("article-key")));
//	});

	var imageUploader = new ImageUploader();
	imageUploader.init();

	$("a[name='docResendMailLink']").attr("href", CommonConstant.DOC_RESEND_MAILTO);
}

function doSubmit() {
	var hasSubmit = localStorage.getItem(LSKey.HAS_APPLICATION_SUBMIT);

	_paq.push(['trackEvent', '雲端櫃台-線上申請信用卡(手機版)-文件上傳(他行信用卡-非本行卡友 & 存款帳號-非本行卡友)', '送出申請', '']);

	if(hasSubmit === "Y") {
		openResultModal(0);
	} else if(hasSubmit === "N") {
		showLoadingView();
		doCM010();
	}
}

function doCM010() {
	var failCount = (localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) ? parseInt(localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) : 0;
	
	CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));

	// 只有第一次發送時夾帶附件圖片
	if(failCount === 0) {
		collectUploadImage();
	}

	CM010RqDataObj.toPDF = "0";
	apiService.doCM010(JSON.stringify(CM010RqDataObj)).then(
	function(rsDataJSON) {
		// doneCallback
		localStorage.setItem(LSKey.HAS_APPLICATION_SUBMIT, "Y");
		hideLoadingView();
		openResultModal(failCount);
	},
	function(xhrStatus) {
		// failCallback
		failCount++;
		localStorage.setItem(LSKey.APPLICATION_FAIL_COUNT, failCount);

		if(failCount === 1) {
			console.log("failCount === 1, before resend CM010, timestamp: " + new Date().getTime());
			sessionStorage.clear();
			// 進行一次retry，重新發送CM010
			setTimeout(function() {
				console.log("resend CM010, timestamp: " + new Date().getTime());
				doCM010();
			}, 2000);
		} else if(failCount > 1) {
			hideLoadingView();
			showErrorPage(apiService.errorMsg.CM010_HTTP_STATUS_503_AND_0 + "(Err Code：" + xhrStatus + ")");
		}
	});
}

function collectUploadImage() {
	CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
	
	var MOCK_DATA = "forPDF";
	var attachmentsNameAry = [];
	var inputFiles = $("#inputFiles input[type='file']");
	inputFiles.each(function() {
		if($(this).val()) {
			var fileBase64 = $(this).data("base64");
			var fileExtensionName = "jpg";
			if($(this).prop("id") === "idFileF") {
				CM010RqDataObj.idFileF = fileBase64;
				CM010RqDataObj.idFileFExtName = fileExtensionName;
				sessionStorage.setItem(LSKey.IMAGE_IDFILE_F, JSON.stringify({idFileFBase64: MOCK_DATA, idFileFExtName: fileExtensionName}));
			} else if($(this).prop("id") === "idFileB") {
				CM010RqDataObj.idFileB = fileBase64;
				CM010RqDataObj.idFileBExtName = fileExtensionName;
				sessionStorage.setItem(LSKey.IMAGE_IDFILE_B, JSON.stringify({idFileBBase64: MOCK_DATA, idFileBExtName: fileExtensionName}));
			} else {
				CM010RqDataObj.attachments.push({file: fileBase64, fileExtName: fileExtensionName});
				attachmentsNameAry.push(this.name);
				sessionStorage.setItem(this.name, JSON.stringify({file: MOCK_DATA, fileExtName: fileExtensionName}));
			}
		}
	});

	if(attachmentsNameAry.length > 0) {
		sessionStorage.setItem(LSKey.ATTACHEMENTS_NAME_ARY, JSON.stringify(attachmentsNameAry));
	}
}

function openResultModal(failCount) {
	console.log('failCount: ' + failCount);

	// 根據錯誤次數show對應的提示內容
	if(failCount === 0) {
		$("#fullSuccess").show();
		$("#partialSuccess").hide();
	} else if(failCount === 1) {
		$("#partialSuccess").show();
		$("#fullSuccess").hide();
	} else {
		return;
	}

	var nowDate = new Date();
	var nowDateY = nowDate.getFullYear();
	var nowDateM = nowDate.getMonth() + 1;
	var nowDateD = nowDate.getDate();
	$("span[data-name='applyDate']").text(nowDateY + "年" + nowDateM + "月" + nowDateD + "日");

	var modal = $("#applicationFinishModal");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			width : ($(window).width() * 0.9) + 'px',
			height : modal.height() + 'px',
			top : '10%',
			left : (($(window).width() * 0.1) / 2) + 'px',
			border: 'none',
			'-webkit-border-radius': '5px',
			'-moz-border-radius': '5px',
			backgroundColor: 'rgba(48,48,48,0.85)'
		}
	});
}

function doFinish() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

function showResultPage() {
	apiService.doSC002().then(function() {
		location.href = "resultPage.html";
	});
}
