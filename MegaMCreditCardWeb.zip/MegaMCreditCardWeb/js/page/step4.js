var hasNotified = false;

$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();

		init();

		startTimer();
	}
});

function init() {
//	$(".c-article-item__title").bind("click", function() {
//		showArticle(decodeArticleContent($(this).data("article-key")));
//	});

	var imageUploader = new ImageUploader();
	imageUploader.init();

	$("a[name='docResendMailLink']").attr("href", CommonConstant.DOC_RESEND_MAILTO);
}

function doSubmit() {
	var hasSubmit = localStorage.getItem(LSKey.HAS_APPLICATION_SUBMIT);

	_paq.push(['trackEvent', '雲端櫃台-線上申請信用卡(手機版)-文件上傳(他行信用卡-非本行卡友 & 存款帳號-非本行卡友)', '送出申請', '']);

	if(hasSubmit === "Y") {
		openResultModal();
	} else if(hasSubmit === "N") {
		showLoadingView();
		sendApplicationInfo();
	}
}

function sendApplicationInfo() {
	$.Deferred().resolve().promise()
	.then(function() {
		return apiService.doCM008();
	})
	.then(function(rsDataJSON) {
		// 組成xml檔名
		var CM008RsDataObj = JSON.parse(rsDataJSON);
		CM010RqDataObj.xmlName = '' + CM008RsDataObj.preDate + CM008RsDataObj.serNo + CommonConstant.UPLOAD_XML_POSTFIX_WITH_FILE_EXT;
		return $.Deferred().resolve(CM008RsDataObj);
	})
	.then(function(CM008RsDataObj) {
		CM010RqDataObj.attachments = [];

		var inputFiles = $("#inputFiles input[type='file']");
		if(inputFiles && inputFiles.length > 0) {
			var uploadPicFileName = CommonConstant.UPLOAD_PIC_PREFIX + CM008RsDataObj.preDate + appendPrefixZero(CM008RsDataObj.serNo, 5);
			var uploadPicExtName = CommonConstant.UPLOAD_PIC_EXT;
			var CM009PromiseAry = [];

			var extraAttachmentCount = 0;
			inputFiles.each(function() {
				if($(this).val()) {
					var failMsg = '圖片上傳失敗';
					var picIdentification = '';

					if($(this).prop("id") === "idFileF") {
						picIdentification = 'nt';
						failMsg = '身分證正面' + failMsg;
					} else if($(this).prop("id") === "idFileB") {
						picIdentification = 'ck';
						failMsg = '身分證反面' + failMsg;
					} else {
						extraAttachmentCount++;
						if(extraAttachmentCount === 1) {
							picIdentification = 'te';
						} else {
							picIdentification = 'e' + extraAttachmentCount;
						}
						failMsg = '財力證明第' + extraAttachmentCount + '張' + failMsg;
					}

					var fileBase64 = $(this).data("base64");
					var fileName = uploadPicFileName + picIdentification + uploadPicExtName;

					CM009PromiseAry.push(function() {
						return doCM009(fileBase64, fileName, failMsg);
					});

					CM010RqDataObj.attachments.push({ fileName: fileName });
				}
			});

			if(CM009PromiseAry.length > 0) {
				var CM009PromiseObj = CM009PromiseAry.reduce(function(prev, curr) {
					return prev.then(curr);
				}, $.Deferred().resolve().promise());
				return CM009PromiseObj;
			} else {
				return $.Deferred().resolve();
			}
		}
	})
	.then(function() {
		doCM010();
	});
}

function doCM009(fileBase64, fileName, failMsg) {
	console.log('doCM009, ' + fileName + ', ' + failMsg);

	var CM009RqDataObj = new CM009RqData();
	CM009RqDataObj.file = fileBase64;
	CM009RqDataObj.fileName = fileName;

	var promiseObj = apiService.doCM009(JSON.stringify(CM009RqDataObj))
	.then(
		function(response) {
			var returnCode = response.responseHeader.returnCode;
			if(returnCode === apiService.returnCode.SUCCESS) {
				return $.Deferred().resolve();
			} else {
				hideLoadingView();
				showErrAlert(failMsg + "(Err Code：" + returnCode + ")");
				return $.Deferred().reject();
			}
		},
		function(xhrStatus) {
			hideLoadingView();
			showErrAlert(failMsg + "(Err Code：" + xhrStatus + ")");
			return $.Deferred().reject();
		}
	);

	return promiseObj;
}

function doCM010() {
	console.log('doCM010');

	var failCount = (localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) ? parseInt(localStorage.getItem(LSKey.APPLICATION_FAIL_COUNT)) : 0;
	
	CM010RqDataObj.toPDF = "0";
	apiService.doCM010(JSON.stringify(CM010RqDataObj)).then(
	function(rsDataJSON) {
		// doneCallback
		localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
		localStorage.setItem(LSKey.HAS_APPLICATION_SUBMIT, "Y");
		hideLoadingView();
		openResultModal();
	},
	function(xhrStatus) {
		// failCallback
		failCount++;
		localStorage.setItem(LSKey.APPLICATION_FAIL_COUNT, failCount);

		if(failCount === 1) {
			console.log("failCount === 1, before resend CM010, timestamp: " + new Date().getTime());
			// 進行一次retry，重新發送CM010
			setTimeout(function() {
				console.log("resend CM010, timestamp: " + new Date().getTime());
				doCM010();
			}, 2000);
		} else if(failCount > 1) {
			hideLoadingView();
			showErrorPage(apiService.errorMsg.CM010_HTTP_STATUS_503_AND_0 + "(Err Code：" + xhrStatus + ")");
		}
	});
}

function openResultModal() {
	var nowDate = new Date();
	var nowDateY = nowDate.getFullYear();
	var nowDateM = nowDate.getMonth() + 1;
	var nowDateD = nowDate.getDate();
	$("span[data-name='applyDate']").text(nowDateY + "年" + nowDateM + "月" + nowDateD + "日");

	var modal = $("#applicationFinishModal");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			height : modal.height() + 'px',
			top : '45%',
			left : '50%',
			width : '80%',
			maxWidth : '800px',
			transform : 'translate(-50%,-50%)',
			border: 'none',
			'-webkit-border-radius': '5px',
			'-moz-border-radius': '5px',
			'border-radius': '5px',
			backgroundColor: 'white'
		}
	});
}

function doFinish() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

function showResultPage() {
	apiService.doSC002().then(function() {
		location.href = "resultPage.html";
	});
}
