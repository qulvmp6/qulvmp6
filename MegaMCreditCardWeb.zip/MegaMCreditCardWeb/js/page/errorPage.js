$(document).ready(function(){
	updatePageNavInfo();

	PageNavigationHandler.backControl();

	init();
});

function init() {
	var errorMsg = localStorage.getItem(LSKey.ERROR_MSG);

	if(errorMsg.indexOf("電腦版") !== -1) {
		$(".c-warning__content").addClass("c-warning__content--user-agent-error");
		$(".c-btn").addClass("u-display--none");
		errorMsg = errorMsg.replaceAll("電腦版", "<a href='" + encodeURI(CommonConstant.PC_VERSION_URL) + "'>電腦版</a>");
	}
	if(errorMsg.indexOf("{highKey}") !== -1) {
		errorMsg = errorMsg.replaceAll("{highKey}", "<span class='u-font--warning u-font-weight--bold'>");
	}
	if(errorMsg.indexOf("{/highKey}") !== -1) {
		errorMsg = errorMsg.replaceAll("{/highKey}", "</span>");
	}
	if(errorMsg.indexOf("{lowKey}") !== -1) {
		errorMsg = errorMsg.replaceAll("{lowKey}", "<span style='color: #D3D3D3;'>");
	}
	if(errorMsg.indexOf("{/lowKey}") !== -1) {
		errorMsg = errorMsg.replaceAll("{/lowKey}", "</span>");
	}
	if(errorMsg.indexOf("{lineBreak}") !== -1) {
		errorMsg = errorMsg.replaceAll("{lineBreak}", "<br>");
	}

	$(".c-warning__content").append(errorMsg);
}

function restartProcess() {
	var queryCodeJSON = localStorage.getItem(LSKey.QUERY_CODE);

	var param = "";
	if(queryCodeJSON) {
		var queryCodeObj = JSON.parse(queryCodeJSON);
		if(queryCodeObj.s) {
			param += "?s=" + queryCodeObj.s;
		}
		if(queryCodeObj.c) {
			param += "?c=" + queryCodeObj.c;
		}
		if(queryCodeObj.e) {
			param += "?e=" + queryCodeObj.e;
		}
		if(queryCodeObj.p) {
			param += "?p=" + queryCodeObj.p;
		}
	}

	if(param.indexOf("?") != -1) {
		var paramFirst = param.substring(0, param.indexOf("?") + 1);
		var paramSecond = param.substring(param.indexOf("?") + 1).replace(new RegExp("\\?", "g"), "&");

		param = paramFirst + paramSecond;
	}

	clearWebStorage();
	location.href = "index.html" + param;
}