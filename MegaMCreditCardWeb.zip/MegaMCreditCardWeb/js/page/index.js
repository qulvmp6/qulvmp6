$(document).ready(function(){
	clearWebStorage();
	if(getQueryCode()) {
		CM010RqDataObj = new CM010RqData();
		VR012RqDataObj = new VR012RqData();
		apiService = new ApiService();
		
		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl();
		showIntroModal();
		init();
		
		/** Validation */
		initValidate();
	}
});

function init() {
	getAllArticle();
	setArticleControl();
	
	initCreditCardSelectList();

	// 大版提供線上填寫，紙本列印選項
	// if(!isMobile()) {
	// 	$('select[name="cardType"]').append("<option value='" + CommonConstant.CARD_TYPE_ONLINE_DOCUMENT + "'>非上述三種身分-線上填寫，紙本列印寄回</option>");
	// }
	
	$(".c-pc-version-link").bind("click", function() {
		location.href = CommonConstant.PC_VERSION_URL;
	});
}

// 向中台取得所有條款內容
function getAllArticle() {
	// 僅在首頁一次取全部的條款，CM001RqData不存於LocalStorage
	var CM001RqDataObj = new CM001RqData();

	CM001RqDataObj.articleCodes.push.apply(CM001RqDataObj.articleCodes, 
		["C1", "C2", "C3", "C4", "C5", "F1", "F2", "F3", "F4"]);
	var CM001RqDataJSON = JSON.stringify(CM001RqDataObj);

	apiService.doCM001(CM001RqDataJSON).then(function(rsDataJSON) {
		var CM001RsDataObj = JSON.parse(rsDataJSON);
		for(var i in CM001RsDataObj.articles) {
			if(CM001RsDataObj.articles[i].articleCode.indexOf(CommonConstant.MEGABANK_ARTICLE_PREFIX,0) === 0) {
				setArticleVersion(CM001RsDataObj.articles[i].articleCode, CM001RsDataObj.articles[i].version);
			}

			// LocalStorage存放條款內容
			localStorage.setItem(CommonConstant.ARTICLE_CODE_PREFIX + CM001RsDataObj.articles[i].articleCode,
				JSON.stringify(CM001RsDataObj.articles[i]));
		}
	}).then(loadFooter);
}

function loadFooter() {
	var footerLoader = $("#footerLoader");
	footerLoader.empty();
	footerLoader.append(decodeArticleContent(footerLoader.data("article-key")));
}

// 記錄條款版本，只有articleCode為C開頭的才有版本
function setArticleVersion(articleCode, version) {
	var paramMapping = "";
	switch(articleCode) {
		case "C1":
			paramMapping = "law_bank";
			break;
		case "C2":
			paramMapping = "law_protect";
			break;
		case "C3":
			paramMapping = "law_fee";
			break;
		case "C4":
			paramMapping = "law_obey";
			break;
		case "C5":
			paramMapping = "law_agree";
			break;
	}

	CM010RqDataObj[paramMapping] = version;
}

function doSubmit() {
	var targetCardName = $("select[name='cardName']").val();
	var targetCardCode = $("select[name='cardKind']").val();
	if(targetCardName && targetCardCode) {
		var targetCard = creditCardsMap[targetCardName][targetCardCode];
		targetCard.cardName = targetCardName;
		localStorage.setItem(LSKey.TARGET_CREDIT_CARD, JSON.stringify(targetCard));
		CM010RqDataObj.cardCode = targetCardCode;
	}

	CM010RqDataObj.feeCode = creditCardsMap[targetCardName][targetCardCode].feeCode;

	var cardType = $("select[name='cardType']").val();
	if(cardType === CommonConstant.CARD_TYPE_MEGABANK) {
		CM010RqDataObj.mIdentifyType = CommonConstant.IDENTIFY_TYPE_MEGABANK;
	} else if (cardType === CommonConstant.CARD_TYPE_OTHERS) {
		CM010RqDataObj.mIdentifyType = CommonConstant.IDENTIFY_TYPE_OTHERS;
	} else if (cardType === CommonConstant.CARD_TYPE_USERVRFY) {
		CM010RqDataObj.mIdentifyType = CommonConstant.IDENTIFY_TYPE_USERVRFY;
	}
 
	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
	localStorage.setItem(LSKey.VR012_RQ_DATA, JSON.stringify(VR012RqDataObj));

	// if(cardType === CommonConstant.CARD_TYPE_ONLINE_DOCUMENT) {
	// 	// 另開視窗線上填寫，紙本列印
	// 	window.open(CommonConstant.ONLINE_DOCUMENT_URL, "_blank");
	// } 
	if (cardType === CommonConstant.CARD_TYPE_USERVRFY) {
		location.href = "step1a.html";
	} else {
		location.href = "step1.html";
	}
}

// 取得URL上的query code
function getQueryCode() {
	var s = getParameterByName("s");
	var c = getParameterByName("c");
	var e = getParameterByName("e");
	var p = getParameterByName("p");

	console.log("s=" + s + ", c=" + c + ", e=" + e + ", p=" + p);

	var errorMsg = "";
	var isValid = true;

	// 其中一個參數有值即視為有效，過濾參數的動作在前導頁(default.jsp)
	if(s || c || e || p) {
		// 代碼英數字檢核
		if(!isNumeric(s)) {
			errorMsg = "通路代碼需為數字";
		} else if(!isNumeric(c)) {
			errorMsg = "指定卡別序號需為數字";
		} else if(!isAlphanumeric(e)) {
			errorMsg = "行銷專員代碼需為英數字";
		} else if(!isAlphanumeric(p)) {
			errorMsg = "客戶識別碼需為英數字";
		} else {
			var queryCode = {
				"s": s,
				"c": c,
				"e": (e.length > 6) ? e.substring(0, 6) : e,
				"p": (p.length > 10) ? p.substring(0, 10) : p
			}

			localStorage.setItem(LSKey.QUERY_CODE, JSON.stringify(queryCode));
		}
	}

	if(errorMsg) {
		isValid = false;
		showErrorPage(errorMsg);
	}
	
	return isValid;
}

// 取得URL上的參數
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return '';
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function isNumeric(inputStr) {
	return /^[0-9]*$/gi.test(inputStr);
}

function isAlphanumeric(inputStr) {
	return /^[a-z0-9]*$/gi.test(inputStr);
}

function initCreditCardSelectList() {
	var queryCodeJSON = localStorage.getItem(LSKey.QUERY_CODE);
	var queryCodeObj = (queryCodeJSON) ? JSON.parse(queryCodeJSON) : "";
	var CM003RqDataObj = new CM003RqData();
	CM003RqDataObj.queryCodeS = (queryCodeObj && queryCodeObj.s) ? queryCodeObj.s : "";
	CM003RqDataObj.queryCodeC = (queryCodeObj && queryCodeObj.c) ? queryCodeObj.c : "";

	var CM003RqDataJSON = JSON.stringify(CM003RqDataObj);

	apiService.doCM003(CM003RqDataJSON).then(function(rsDataJSON) {
		var CM003RsDataObj = JSON.parse(rsDataJSON);

		// update CM010RqDataObj.cIntrId，優先序：p值>CM003.RS.cIntrId>空值
		var cIntrId = "";
		var queryCodeP = (queryCodeObj && queryCodeObj.p) ? queryCodeObj.p : "";
		if(queryCodeP) {
			cIntrId = queryCodeP;
		} else if(CM003RsDataObj.cIntrId) {
			cIntrId = CM003RsDataObj.cIntrId;
		}
		CM010RqDataObj.cIntrId = cIntrId;

		var defaultCard = CM003RsDataObj.defaultCard;
		var creditCards = CM003RsDataObj.creditCards;

		var targetCardName = "";
		creditCardsMap = {};
		$("select[name='cardName']").empty();
		$("select[name='cardName']").append("<option value=''>請選擇信用卡</option>");
		creditCards.forEach(function(card) {
			var currentCardName = card.cardName;
			$("select[name='cardName']").append("<option value='" + currentCardName +"'>" + currentCardName +"</option>");

			var cardKindsMap = {};
			card.cardKinds.forEach(function(kind) {
				if(kind.cardCode == defaultCard) {
					targetCardName = currentCardName;
				}
				cardKindsMap[kind.cardCode] = kind;
			});
			creditCardsMap[card.cardName] = cardKindsMap;
		});

		// 若對應不到信用卡，顯示第一筆
		if(!targetCardName) {
			targetCardName = creditCards[0].cardName;
			defaultCard = creditCards[0].cardKinds[0].cardCode;
		}

		$("select[name='cardName']").val(targetCardName);
		updateCardKindSelectList(targetCardName);

		$("select[name='cardKind']").val(defaultCard);
		updatePreviewImage(targetCardName, defaultCard);
	});
}

function onCardNameChange() {
	var targetCardName = $("select[name='cardName']").val();
	var cardKindsSelectList = $("select[name='cardKind']");

	if(targetCardName) {
		updateCardKindSelectList(targetCardName);
		cardKindsSelectList.prop("disabled", false);
		cardKindsSelectList.parent().removeClass("c-select-wrapper__disabled");
	} else {
		cardKindsSelectList.val("");
		cardKindsSelectList.prop("disabled", true);
		cardKindsSelectList.parent().addClass("c-select-wrapper__disabled");

		$(".c-img--credit-card-preview").hide();
	}
}

function onCardKindChange() {
	var targetCardName = $("select[name='cardName']").val();
	var targetCardCode = $("select[name='cardKind']").val();

	if(targetCardName && targetCardCode) {
		updatePreviewImage(targetCardName, targetCardCode);
	} else {
		$(".c-img--credit-card-preview").hide();
	}
}

function updateCardKindSelectList(targetCardName) {
	var targetCardKinds = creditCardsMap[targetCardName];
	$("select[name='cardKind']").empty();
	$("select[name='cardKind']").append("<option value=''>請選擇信用卡細項</option>");
	// targetCardKinds.forEach(function(kind) {
	$.each(targetCardKinds,function(index,kind) {
		$("select[name='cardKind']").append("<option value='" + kind.cardCode +"'>" + kind.cardKind +"</option>");
	
	});

	// 若只有一筆就自動帶出
	if(Object.keys(targetCardKinds).length === 1) {
		var targetCardCode = Object.keys(targetCardKinds)[0];
		$("select[name='cardKind']").val(targetCardCode);
		updatePreviewImage(targetCardName, targetCardCode);
	} else {
		$(".c-img--credit-card-preview").hide();
	}
}

function updatePreviewImage(targetCardName, targetCardCode) {
	if(targetCardName && targetCardCode) {
		var imgSrc = creditCardsMap[targetCardName][targetCardCode].picUrl;
		$(".c-img--credit-card-preview").attr("src", imgSrc);
		$(".c-img--credit-card-preview").show();
	}
}

function initValidate() {
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		messages: {
			cardName: {
				required: "請選擇您要申請的信用卡"
			},
			cardKind: {
				required: "請選擇您要申請的信用卡"
			},
			cardType: {
				required: "請選擇身分驗證方式"
			},
			article_C1: {
				required: "請先閱讀銀行業務服務契約約定條款"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(this).removeClass('is-invalid');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,element){
					$(errorList[index].element).addClass('is-invalid');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}

function showIntroModal() {
	setCheckBoxExclusive("user-type");

	$("#introModal .c-modal__act-bar .c-btn").prop("disabled", true);

	var emphasisFontSize = ($(window).width() > 320) ? '.85em' : '.8em';
	$('input[name="user-type"]:checkbox').click(function () {
		$("#introModal .c-modal__act-bar .c-btn").prop("disabled", false);

        if($('input[name="user-type"]:checked').attr('id') == 'new') {
            $('select[name="cardType"] option[value=1]').prop('selected', false);
            $('select[name="cardType"] option[value=9]').prop('selected', true);
            $('.isCardFriend').hide();
            $('.isNotCardFriend').show();
        }
        if ($('input[name="user-type"]:checked').attr('id') == 'old') {
            $('select[name="cardType"] option[value=9]').prop('selected', false);
            $('select[name="cardType"] option[value=1]').prop('selected', true);
            $('.isNotCardFriend').hide();
            $('.isCardFriend').show();
        }
    });

    $("#introModal .c-modal__act-bar .c-btn").unbind();
    $("#introModal .c-modal__act-bar .c-btn").bind("click", function() {
    	$.unblockUI();
    });

    $('input[name="user-type"]#old').trigger('click');

    var suggestion = "";
    if(isMobile()) {
    	suggestion = "建議使用iOS(Safari)9.0含以上及Android(Chrome)5.0 含以上的瀏覽器，若使用手機自建瀏覽器(小米、三星、LINE瀏覽器)，可能會造成部分網頁功能無法正常運作。";
    } else {
    	suggestion = "建議使用IE 10以上或其他如Chrome、Edge、FireFox、Safari的最新版本瀏覽器，否則可能會造成部分網頁功能無法正常運作。";
    }
    $('#suggestion').text(suggestion);

	var cssTop = '';
	var widthProportion = 0
	var screenWidth = $(window).width();
	if(screenWidth <= 320) {
		cssTop = '1%';
		widthProportion = 0.95;
	} else if(screenWidth > 320 && screenWidth <= 600) {
		cssTop = '6%';
		widthProportion = 0.9;
	} else if(screenWidth > 600 && screenWidth <= 1200) {
		cssTop = '12%';
		widthProportion = 0.8;
	} else {
		// screenWidth > 1200
		cssTop = '12%';
		widthProportion = 0.65;
	}

	var modal = $("#introModal");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			width : ($(window).width() * widthProportion) + 'px',
			height : modal.height() + 'px',
			//position: 'absolute',	// make modal scrollable
			top : cssTop,
			left : (($(window).width() * (1-widthProportion) ) / 2) + 'px',
			// top : '45%',
			// left : '50%',
			// width : '80%',
			//maxWidth : '800px',
			//transform : 'translate(-50%,-50%)',
			border: 'none',
			'-webkit-border-radius': '5px',
			'-moz-border-radius': '5px',
			'border-radius': '5px',
			backgroundColor: 'white'
		}
	});
}

