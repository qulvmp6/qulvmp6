$(document).ready(function(){
	if(checkUserAgent() && checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.CM002_RS_DATA, LSKey.TARGET_CREDIT_CARD])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		CM002RsDataObj = JSON.parse(localStorage.getItem(LSKey.CM002_RS_DATA));
		apiService = new ApiService();

		setProcessImg(CM010RqDataObj.isOrigin);

		targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		addrZoneMap = new Map();
		var addrZoneList = CM002RsDataObj.addrZone;
		addrZoneList.forEach(function(addrZone) {
			addrZoneMap.set(addrZone.city, addrZone.dists);
		});
		isAutoPayReset = false;

		init();
		initValidate();

		startTimer();
	}
});

function displayBillAddress() {
	$("#hasBillAddress").hide();
	$("#biillAddress").text('');
	var CardFriendInfoObj = JSON.parse(localStorage.getItem(LSKey.CARD_FRIEND_INFO));
	var VR012RsDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RS_DATA));
	if(CardFriendInfoObj){
		if(CardFriendInfoObj.cardFlag == '0' && CardFriendInfoObj.billAddr) {	
			$("#hasBillAddress").show();
			$("#biillAddress").text(maskAllNumbers(CardFriendInfoObj.billAddr));
		}	
	}
	if(VR012RsDataObj){
		if(VR012RsDataObj.isCardFriend == 'Y' && VR012RsDataObj.billAddr) {	
			$("#hasBillAddress").show();
			$("#biillAddress").text(maskAllNumbers(VR012RsDataObj.billAddr));
		}	
	}
	
}

function maskAllNumbers(text) {
    var maskedNumber = textHandler(/[0-9]/g, text, '');
    var maskedFullWidthNumber = textHandler(/[\uff10-\uff19]/g, maskedNumber, '');
    return maskedFullWidthNumber;
}

function textHandler(regex, text, character) {
	var matchedArray = regex.exec(text);
    if(!matchedArray) return text;
    var group = matchedArray[0];
    var length = group.replace(character,'').length;
    var str = '';
    for(var i = 0;i<length;i++){
       str+='*';
    }
    str+=character;
    text = text.replace(regex, str);
	return text;
}

function init() {
	displayBillAddress();
	setArticleControl();

	$("#serviceLocationLink").prop("href", CommonConstant.SERVICE_LOCATION_URL);

	// 本行正卡持有人，結帳日比照原結帳日，不需選擇
	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
		$("#cPayMentDueDateChoiceIsOrigin").show();
		$("#cPayMentDueDateChoice").hide();
	} else {
		$("#cPayMentDueDateChoiceIsOrigin").hide();
		$("#cPayMentDueDateChoice").show();
	}

	// 自動扣款同意條款
	if(targetCard.isCombo === "Y") {
		$("#autoPayArticle").show();
	}

	// 信用卡補充條款呈現，針對換行符號替換成br tag
	if(targetCard.additional) {
		var additionalArticleContent = (targetCard.additional).replace(/(?:\r\n|\r|\n)/g, "<br>");
		$("#additionalArticle").html(stripXSS(additionalArticleContent));
		$("#additionalArticle").show();
	}

	initFormControl();
	initSelectList();
	initCoBranderCardArticle();
	setCheckBoxExclusive("cBrandedCardFlag");
	setCheckBoxExclusive("mCardTo");
	setCheckBoxExclusive("mNormalCardOpt");
	setCheckBoxExclusive("autoPayAgreement");
	setCheckBoxExclusive("autoPayAgreeChoice");
	initResetButton();
	initAutoPayInfo();
}

// 聯名卡同意條款初始化
function initCoBranderCardArticle() {
	var CM005RqDataObj = new CM005RqData();
	CM005RqDataObj.cardCode = CM010RqDataObj.cardCode;
	apiService.doCM005(JSON.stringify(CM005RqDataObj)).then(function(rsDataJSON) {
		if(rsDataJSON) {
			var CM005RsDataObj = JSON.parse(rsDataJSON);
			$("#cbcArticleLeadingText").text(CM005RsDataObj.leadingText);
			$("#cbcArticleContent").text(CM005RsDataObj.article);
			$("#coBranderCardArticle").show();
		} else {
			// 非聯名卡
			$("#coBranderCardArticle").hide();
		}
	});
}

function initSelectList() {
	var payMentDueDateList = CM002RsDataObj.payMentDueDate;
	payMentDueDateList.forEach(function(payMentDueDateInfo) {
		$("select[name='cPayMentDueDate']").append("<option value='" + payMentDueDateInfo.key + "'>" + payMentDueDateInfo.value + "</option>");
	});
}

function initFormControl() {
	// 自動扣款同意條款checkbox控制
	$("input[name='autoPayAgreement']").change(function() {
		if($(this).attr("id") === "autoPayAgreement_N") {
			$("input[name='autoPayAgreeChoice']").prop("checked", false);
			$("input[name='cPrimAccountNo']").val("");
		}
	});

	$("input[name='autoPayAgreeChoice']").change(function() {
		if(!$("#autoPayAgreement_Y").prop("checked")) {
			$("input[name='autoPayAgreement']").prop("checked", false);
			$("#autoPayAgreement_Y").prop("checked", true);
		}
	});
}
function initResetButton() {
	$("#resetButton").click(function() {
		$("#autoPayAgreeChoice_full").prop("checked", false);
		$("#autoPayAgreeChoice_min").prop("checked", false);
		$("#autoPayAgreeChoice_full").prop("disabled", false);
		$("#autoPayAgreeChoice_min").prop("disabled", false);
		$("input[name='cPrimAccountNo']").val("");
		$("input[name='cPrimAccountNo']").prop("disabled", false);
		$("#bank").text("017");
		isAutoPayReset = true;
	});
}

function initAutoPayInfo() {
	if(targetCard.isCombo !== "Y") return;

	var CardFriendInfoObj = JSON.parse(localStorage.getItem(LSKey.CARD_FRIEND_INFO));
	var VR012RsDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RS_DATA));

	var defaultAutoPayIndicator = "";
	var defaultAutoPayAcctBank = "";
	var defaultAutoPayAcctNo = "";

	noPreviousAutoPaySetting = true;

	// 若為卡友且設定過自扣，收集自扣資訊
	if(CardFriendInfoObj && CardFriendInfoObj.cardFlag == '0' && (CardFriendInfoObj.autoPayIndicator && CardFriendInfoObj.autoPayIndicator !='3') && CardFriendInfoObj.autoPayAcctBank  && CardFriendInfoObj.autoPayAcctNo){
		noPreviousAutoPaySetting = false;
		defaultAutoPayIndicator = CardFriendInfoObj.autoPayIndicator;
		defaultAutoPayAcctBank = CardFriendInfoObj.autoPayAcctBank;
		defaultAutoPayAcctNo = CardFriendInfoObj.autoPayAcctNo;
	} else if(VR012RsDataObj && VR012RsDataObj.isCardFriend == 'Y' && (VR012RsDataObj.autoPayIndicator && VR012RsDataObj.autoPayIndicator !='3') && VR012RsDataObj.autoPayAcctBank  && VR012RsDataObj.autoPayAcctNo) {
		noPreviousAutoPaySetting = false;
		defaultAutoPayIndicator = VR012RsDataObj.autoPayIndicator;
		defaultAutoPayAcctBank = VR012RsDataObj.autoPayAcctBank;
		defaultAutoPayAcctNo = VR012RsDataObj.autoPayAcctNo;
	}

	if(noPreviousAutoPaySetting) {
		// 未設定過自扣，隱藏修改鈕
		$("#resetButtonBlock").hide();
	} else {
		// 設定過自扣，帶出預設自扣資訊
		(defaultAutoPayIndicator === "1") ? $("#autoPayAgreeChoice_full").prop("checked", true) : $("#autoPayAgreeChoice_min").prop("checked", true);
		$("#bank").text(defaultAutoPayAcctBank);
		$("input[name='cPrimAccountNo']").val(defaultAutoPayAcctNo);

		$("input[name='cPrimAccountNo']").prop("disabled", true);
		$("#autoPayAgreeChoice_full").prop("disabled", true);
		$("#autoPayAgreeChoice_min").prop("disabled", true);

		$("#autoPayAgreement_Y").prop("checked", true);

		// 不允許選擇不同意
		$("#autoPayAgreement_N").prop("disabled", true);
	}
}
function showServiceLocationModal() {
	initModalSelectList();

	var modal = $("#serviceLocationModal");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			width : ($(window).width() * 0.7) + 'px',
			height : modal.height() + 'px',
			top : '10%',
			left : (($(window).width() * 0.3) / 2) + 'px',
			border: 'none',
			'-webkit-border-radius': '5px',
			'-moz-border-radius': '5px',
			backgroundColor: 'rgba(48,48,48,0.85)'
		}
	});
}

function initModalSelectList() {
	$("select[name='servLocCity']").empty();
	$("select[name='servLocCity']").append("<option value=''>縣市</option>");

	$("select[name='servLocDist']").empty();
	$("select[name='servLocDist']").append("<option value=''>鄉鎮市區</option>");
	$("select[name='servLocDist']").prop("disabled", true);
	$("select[name='servLocDist']").parent().addClass("c-select-wrapper__disabled");

	$("select[name='servLocBranch']").empty();
	$("select[name='servLocBranch']").append("<option value=''>服務據點</option>");
	$("select[name='servLocBranch']").prop("disabled", true);
	$("select[name='servLocBranch']").parent().addClass("c-select-wrapper__disabled");

	var addrZoneList = CM002RsDataObj.addrZone;
	addrZoneList.forEach(function(addrZone) {
		$("select[name='servLocCity']").append("<option value='" + addrZone.city + "'>" + addrZone.city + "</option>");
	});

	$("select[name='servLocCity']").change(function() {
		onServLocCityChange();
	});

	$("select[name='servLocDist']").change(function() {
		onServLocDistChange();
	});
}

function onServLocCityChange() {
	var city = $("select[name='servLocCity']").val();
	if(city) {
		var distList = addrZoneMap.get(city);
		$("select[name='servLocDist']").empty();
		$("select[name='servLocDist']").append("<option value=''>鄉鎮市區</option>");
		distList.forEach(function(distInfo) {
			$("select[name='servLocDist']").append("<option value='" + distInfo.postalCode + "'>" + distInfo.dist + "</option>");
		});

		$("select[name='servLocDist']").prop("disabled", false);
		$("select[name='servLocDist']").parent().removeClass("c-select-wrapper__disabled");
	} else {
		$("select[name='servLocDist']").val("");
		$("select[name='servLocDist']").prop("disabled", true);
		$("select[name='servLocDist']").parent().addClass("c-select-wrapper__disabled");

		$("select[name='servLocBranch']").val("");
		$("select[name='servLocBranch']").prop("disabled", true);
		$("select[name='servLocBranch']").parent().addClass("c-select-wrapper__disabled");
	}
}

function onServLocDistChange() {
	var postalCode = $("select[name='servLocDist']").val();
	if(postalCode) {
		var CM004RqDataObj = new CM004RqData();
		CM004RqDataObj.postalCode = postalCode;
		apiService.doCM004(JSON.stringify(CM004RqDataObj)).then(function(rsDataJSON) {
			var CM004RsDataObj = JSON.parse(rsDataJSON);
			var branchList = CM004RsDataObj.branches;

			$("select[name='servLocBranch']").empty();
			$("select[name='servLocBranch']").append("<option value=''>服務據點</option>");
			branchList.forEach(function(branchInfo) {
				$("select[name='servLocBranch']").append("<option value='" + branchInfo.code + "'>" + branchInfo.name + "</option>");
			});
		});

		$("select[name='servLocBranch']").prop("disabled", false);
		$("select[name='servLocBranch']").parent().removeClass("c-select-wrapper__disabled");
	} else {
		$("select[name='servLocBranch']").val("");
		$("select[name='servLocBranch']").prop("disabled", true);
		$("select[name='servLocBranch']").parent().addClass("c-select-wrapper__disabled");
	}
}

function cancel() {
	$.unblockUI();
}

function confirm() {
	var branchSelectList = $("select[name='servLocBranch']");
	var resultBranchName = "";
	if(branchSelectList.val()) {
		resultBranchName = branchSelectList.find("option:selected").text();
		CM010RqDataObj.cNote10 = branchSelectList.val();
	} else {
		CM010RqDataObj.cNote10 = "";
	}

	$("input[name='cNote10']").val(resultBranchName);

	$.unblockUI();
}

function doSubmit() {
	if($("#coBranderCardArticle:visible").length > 0 && $("#cBrandedCardFlag_Y:checked").length < 1) {
		$("#cBrandedCardFlag_Y").goTo();
		showToast("未勾選視為不同意，如勾選不同意，則無法申辦本聯名卡!");
		return;
	}

	updateCM010RqDataObj();

	localStorage.setItem(LSKey.HAS_APPLICATION_SUBMIT, "N");
	localStorage.setItem(LSKey.APPLICATION_FAIL_COUNT, "0");

	apiService.doSC002().then(function() {
		location.href = "step3_2.html";
	});
}

function updateCM010RqDataObj() {
	if($("#coBranderCardArticle:visible").length > 0) {
		if($("#cBrandedCardFlag_Y:checked").length > 0) {
			CM010RqDataObj.cBrandedCardFlag = "1";
		} else {
			CM010RqDataObj.cBrandedCardFlag = "2";
		}
	} else {
		// 	非聯名卡
		CM010RqDataObj.cBrandedCardFlag = "0";
	}

	if($("#bySelf:checked").length > 0) {
		CM010RqDataObj.mCardTo = CommonConstant.CARD_TO_BY_SELF;
	} else {
		CM010RqDataObj.mCardTo = CommonConstant.CARD_TO_BY_POST;
		CM010RqDataObj.cNote10 = "";
	}

	if($("#mNormalCardOpt_N:checked").length > 0) {
		CM010RqDataObj.mNormalCardOpt = "0";
	} else {
		CM010RqDataObj.mNormalCardOpt = "1";
	}

	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
		CM010RqDataObj.cPayMentDueDate = "";
	} else {
		if($("select[name='cPayMentDueDate']").val()) {
			CM010RqDataObj.cPayMentDueDate = $("select[name='cPayMentDueDate'] option:selected").text();
		}
	}

	if(targetCard.isCombo === "Y") {
		if(isAutoPayReset || noPreviousAutoPaySetting) {
			if($("#autoPayAgreement_Y").is(":checked")) {
				if($("#autoPayAgreeChoice_full").prop("checked")) CM010RqDataObj.mNote9 = "1";
				if($("#autoPayAgreeChoice_min").prop("checked")) CM010RqDataObj.mNote9 = "2";
				var cPrimAccountNo = $("input[name='cPrimAccountNo']").val();
				CM010RqDataObj.cPrimAccountNo = appendPrefixZero(cPrimAccountNo, 11);// 扣款帳戶，未滿11碼左方補零至11碼
			} else {
				CM010RqDataObj.mNote9 = "";
				CM010RqDataObj.cPrimAccountNo = "";
			}
		} else {
			// 有預設自扣，且未點擊修改鈕重置
			CM010RqDataObj.mNote9 = "";
			CM010RqDataObj.cPrimAccountNo = "";
		}

	}
	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
}

function initValidate() {
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cBrandedCardFlag: {
				required: {
					depends: function() {
						return $("#coBranderCardArticle:visible").length > 0;
					}
				}
			},
			mCardTo: {
				required: true
			},
			cNote10: {
				required: {
					depends: function() {
						return $("#bySelf:checked").length > 0;
					}
				}
			},
			mNormalCardOpt: "required",
			autoPayAgreeChoice: {
				required: {
					depends: function() {
						return $('#autoPayAgreement_Y').is(":checked") || $("input[name='cPrimAccountNo']").val().length > 0;
					}
				}
			},
			cPrimAccountNo: {
				required: {
					depends: function() {
						return $('#autoPayAgreement_Y').is(":checked") || $('#autoPayAgreeChoice_min').is(":checked") || $('#autoPayAgreeChoice_full').is(":checked");
					}
				},
				digits: true
			}
		},
		messages: {
			article_C5: {
				required: "請先閱讀聲明同意條款"
			},
			cBrandedCardFlag: {
				required: "請進行聯名卡條款同意選擇"
			},
			mCardTo: {
				required: "請選擇信用卡領取方式"
			},
			cNote10: {
				required: "請選擇分部/分行"
			},
			mNormalCardOpt: {
				required: "請進行改申其他卡同意選擇"
			},
			autoPayAgreeChoice: {
				required: "請進行自動扣款金額選擇"
			},
			cPrimAccountNo: {
				required: "請輸入扣款帳戶",
				digits: "僅限輸入數字"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = errorList.findIndex(function(errElement) {
						return errElement.element.name === element.name;
					});
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showToast(errorList[0].message);
			}
		}
	});
}
