var _paq = _paq || [];
(function () {
    var u="https://webdba.megabank.com.tw/piwik/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', getPiwikSiteId()]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src='js/piwik.js'; s.parentNode.insertBefore(g,s);

  var ie = !!(window.attachEvent && !window.opera);
  var wk = /webkit\/(\d+)/i.test(navigator.userAgent) && (RegExp.$1 < 525);
  var fn = [];
  var run = function () { for (var i = 0; i < fn.length; i++) fn[i](); };
  var d = document;
  d.ready = function (f) {
    if (!ie && !wk && d.addEventListener)
      return d.addEventListener('DOMContentLoaded', f, false);
    if (fn.push(f) > 1) return;
    if (ie)
      (function () {
        try { d.documentElement.doScroll('left'); run(); }
        catch (err) { setTimeout(arguments.callee, 0); }
      })();
    else if (wk)
      var t = setInterval(function () {
        if (/^(loaded|complete)$/.test(d.readyState))
          clearInterval(t), run();
      }, 0);
  };
})();

document.ready(function(){
	var breadcrumb=document.getElementsByClassName("breadcrumb");
	var mainForm=document.getElementById('main');
	
	if (breadcrumb === null || mainForm === null){
		_paq.push(['trackPageView']);
		_paq.push(['enableLinkTracking']);

	}else{
		var innerHtml = breadcrumb[0].innerHTML;
		
		var pageTitle = innerHtml.substring(innerHtml.lastIndexOf(">")+1).trim();
		var pageUrl = mainForm.getAttribute('action');

		_paq.push(['setCustomUrl', pageUrl]);
		_paq.push(['setDocumentTitle', pageTitle]);
		_paq.push(['trackPageView']);
		_paq.push(['enableLinkTracking']);
		_paq.push(['trackEvent', pageTitle, window.location.href]);
	}
	
});
