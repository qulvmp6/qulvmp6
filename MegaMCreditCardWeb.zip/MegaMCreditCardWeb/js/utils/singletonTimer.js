var SingletonTimer = function() {
	if(typeof SingletonTimer.instance === 'object') {
		return SingletonTimer.instance;
	}
	
	var e = this;
	SingletonTimer.instance = e;
	e.timer = null;
	e.interval = null;
	
	e.timestamp = new Date().getTime();

	// 完整倒數秒數
	e.tokenTimeSec = (localStorage.getItem(LSKey.TOKEN_TIME)) ? parseInt(localStorage.getItem(LSKey.TOKEN_TIME)) : 300;
	
	// 倒數秒數剩餘tokenTimeoutAlertTimeSec時，popup倒數視窗
	e.tokenTimeoutAlertTimeSec = (localStorage.getItem(LSKey.TIMEOUT_ALERT_TIME)) ? parseInt(localStorage.getItem(LSKey.TIMEOUT_ALERT_TIME)) : 60;
	
	// 解除倒數
	e.clear = function() {
		if(Environment.MODE === "DEV") {
			return;
		}

		// console.log("timestamp = " + e.timestamp + ", timer clear");
		if(e.timer) {
			clearTimeout(e.timer);
		}
	};

	// 啟動倒數
	e.start = function() {
		if(Environment.MODE === "DEV") {
			return;
		}

		// console.log("timestamp = " + e.timestamp + ", timer start: " + new Date());
		e.timer = setTimeout(function() {
			// console.log("timestamp = " + e.timestamp + ", timer end: " + new Date());
			e.openCountDownModal(e.tokenTimeoutAlertTimeSec);
		}, (e.tokenTimeSec - e.tokenTimeoutAlertTimeSec) * 1000);
	};

	// 重啟倒數
	e.restart = function() {
		if(Environment.MODE === "DEV") {
			return;
		}
		
		// console.log("timestamp = " + e.timestamp + ", timer restart");
		e.clear();
		e.start();
	};
	
	// 開啟倒數視窗
	e.openCountDownModal = function(countDownSec) {
		if($(".c-modal-loader").length == 0) {
			$(".c-page-container").append("<div class='c-modal-loader'></div>");
		}

		var modalLoader = $(".c-modal-loader");
		modalLoader.empty();
		modalLoader.load("components/timeOutCountDownModal.html", function() {
			var modalWidth = $(window).width() * 0.7;
			modalWidth = (modalWidth > 800) ? 800 : modalWidth;

			var modalLeft = ($(window).width() - modalWidth) / 2;

			$("#countDownSec").text(countDownSec);
		    $.blockUI({
		        message : modalLoader,
		        fadeIn: 0,
		        css : {
		            cursor : null,
		            width : modalWidth + 'px',
		            height : modalLoader.height() + 'px',
		            top : '25%',
		            left : modalLeft + 'px',
		            border: 'none',
		            '-webkit-border-radius': '5px',
					'-moz-border-radius': '5px',
					'border-radius': '5px',
		            backgroundColor: 'white'
		        }
		    });
		    
		    e.doCountDown();
		    
		    $("#countDownModal .c-modal__act-bar .c-btn--right").unbind();
		    $("#countDownModal .c-modal__act-bar .c-btn--right").bind("click", function() {
		    	e.keepUsing();
		    });
		    
		    $("#countDownModal .c-modal__act-bar .c-btn--left").unbind();
		    $("#countDownModal .c-modal__act-bar .c-btn--left").bind("click", function() {
		    	e.leavePage();
		    });
		});
	};
	
	e.doCountDown = function() {
		e.interval = setInterval(function() {
			var countDownSec = $("#countDownSec").text();
			if(countDownSec > 0) {
				countDownSec--;
				$("#countDownSec").text(countDownSec);
			} else {
				clearInterval(e.interval);
				stopTimer();
				showErrorPage("逾時未使用，請重新登入");
			}
		}, 1000);
	};
	
	// 繼續使用，呼叫SC002延長token時間，並重啟倒數
	e.keepUsing = function() {
		var apiService = new ApiService();
		apiService.doSC002().then(function() {
			clearInterval(e.interval);
			restartTimer();
			$.unblockUI();
		});
	};
	
	e.leavePage = function() {
		stopTimer();
		clearWebStorage();
		location.href = CommonConstant.HOME_PAGE_URL;
	};
};

SingletonTimer.getInstance = function() {
	var singletonTimer = new SingletonTimer();
    return singletonTimer;
};
