var ImageUploader = function() {
	var e = this;

	e.compassConfig = {
		longSide: 800,
		shortSide: 600,
		quality: 1.0
	};

	e.act = {
		doUpload: "upload",
		doDelete: "delete"
	};

	e.text = {
		main: {
			selectFile: "選擇檔案",
			removeFile: "刪除",
			emptyFile: "未選擇任何檔案"
		},
		extra: {
			selectFile: "繼續上傳",
			removeFile: "刪除",
			emptyFile: "未選擇任何檔案"
		}
	};

	e.maxExtraAttachments = 4;

	e.init = function() {
		var uploaders = $(".imgUploader");
		uploaders.each(function() {
			var input = document.createElement("input");
			var uploaderName = $(this).data("name");
			e.createInputFile(uploaderName);
		});

		uploaders.bind("click", function() {
			var uploaderName = $(this).data("name");
			e.onUploadBtnClick(uploaderName);
			//綁垃圾桶圖示也能刪除
			$('button[data-name="'+uploaderName+'"] ~ .c-delete-img').bind('click',function(){
				e.onUploadBtnClick(uploaderName);
			});
		});    		
	};

	// 為上傳元件建立對應的input file元件
	e.createInputFile = function(uploaderName) {
		var input = document.createElement("input");
		input.type = "file";
		input.accept = "image/*";
		input.id = uploaderName;
		input.name = uploaderName;
		input.classList.add("u-display--none");

		input.onchange = function(){
			var fileName = "";
			var uploader = $(".imgUploader[data-name='" + uploaderName + "']");
			if(this.files[0]) {
				fileName = this.files[0].name;
				e.imgToBase64(this);
				uploader.text(e.text.main.removeFile);
				uploader.removeClass("c-btn--ivory");
				uploader.addClass("c-btn--dark-red");
				uploader.data("act", e.act.doDelete);

				if(uploaderName == "attachement") {
					if($("#extraAttachments .imgUploader").length == 0) {
						$("#extraAttachments").show();
						e.addExtraUploader();
					}
				} else if(uploaderName.indexOf("attachement_",0) === 0) {
					if($("#extraAttachments .imgUploader").length < e.maxExtraAttachments) {
						e.addExtraUploader();
					}
				}
			} else {
				fileName = e.text.main.emptyFile;
				uploader.text(e.text.main.selectFile);
				uploader.removeClass("c-btn--dark-red");
				uploader.addClass("c-btn--ivory");
				uploader.data("act", e.act.doUpload);
			}
			uploader.parent().siblings(".c-img-name").text(fileName);
		}

		// 將input file集中存放
		$("#inputFiles").append(input);
	};

	e.onUploadBtnClick = function(uploaderName) {
		var uploader = $(".imgUploader[data-name='" + uploaderName + "']");
		if(uploader.data("act") == e.act.doUpload) {
			$("#" + uploaderName).trigger("click");
		} else if(uploader.data("act") == e.act.doDelete) {
			var btnText = e.text.main.emptyFile;
			var fileName = e.text.main.selectFile;
			if(uploaderName.indexOf("attachement_",0) === 0) {
				btnText = e.text.extra.emptyFile;
				fileName = e.text.extra.selectFile;
				if($("#extraAttachments .imgUploader").length > 1) {
					$("#" + uploaderName).remove();
					uploader.parents(".c-upload").remove();
				}

				var extraIdleUploaderNum = $("#extraAttachments .imgUploader").filter(function() { 
					return $(this).data("act") == e.act.doUpload; 
				}).length;
				console.log(extraIdleUploaderNum);
				if(extraIdleUploaderNum < 1) {
					e.addExtraUploader();
				}
			}

			$("#" + uploaderName).val("");
			uploader.parent().siblings(".c-img-name").text(btnText);
			uploader.text(fileName);
			uploader.removeClass("c-btn--dark-red");
			uploader.addClass("c-btn--ivory");
			uploader.data("act", "upload");
			console.log(uploaderName);
			if($(window).width() > 960){
				$('button[data-name="'+uploaderName+'"]').css("background-image", "url('assets/box.png')");
				$('button[data-name="'+uploaderName+'"]').css("background-size", "100px");
				$('button[data-name="'+uploaderName+'"] ~ .c-watermark').hide();
				$('button[data-name="'+uploaderName+'"] ~ .c-delete-img').hide();
			}
		}
	};

	e.imgToBase64 = function(inputFileElem) {
		var canvas = document.createElement("canvas");
		var mpImg = new MegaPixImage(inputFileElem.files[0]);
		var options = { 
			width: e.compassConfig.shortSide, 
			height: e.compassConfig.longSide
		};

		mpImg.render(canvas, options, function() {
			// result為圖片base64 encode，後續傳給中台
			var result = canvas.toDataURL("image/jpeg", e.compassConfig.quality);
			$("#" + inputFileElem.id).data("base64", result.split(",")[1]);
			//$("#" + inputFileElem.id).css("background-image", "url('"+ result +"')");
			if($(window).width() > 960){
				$('button[data-name="'+inputFileElem.id+'"]').css("background-image", "url('"+ result +"')");
				$('button[data-name="'+inputFileElem.id+'"]').css("background-size", "250px 150px");
				$('button[data-name="'+inputFileElem.id+'"] ~ .c-watermark').show();
				$('button[data-name="'+inputFileElem.id+'"] ~ .c-delete-img').show();
			}
		});
	};

	// 動態新增上傳元件，bind click event
	e.addExtraUploader = function() {
		var uploaderName = "attachement_" + new Date().getTime();
		var extraUploaderHtml = "<div class='c-upload o-display-table'>" +
			"<div class='u-width--40 u-v-align--middle'>" +
			"<button class='imgUploader c-btn c-btn--large c-btn--ivory' type='button' data-name='" + uploaderName + "' data-act='" + e.act.doUpload + "'>" + e.text.extra.selectFile + "</button>" +
			"<div class='c-watermark'>限申請兆豐信用卡使用</div>"+
			"<div class='c-delete-img'><img src='assets/delete.png' width='70'></div>"+
			"</div>" +
			"<div class='c-img-name'>" + e.text.extra.emptyFile + "</div>" +
			"</div>";
		$("#extraAttachments").append(extraUploaderHtml);

		var uploader = $(".imgUploader[data-name='" + uploaderName + "']");

		e.createInputFile(uploaderName);
		uploader.bind("click", function() {
			e.onUploadBtnClick(uploaderName);
			//綁垃圾桶圖示也能刪除
			$('button[data-name="'+uploaderName+'"] ~ .c-delete-img').bind('click',function(){
				e.onUploadBtnClick(uploaderName);
			});
		});
	};
};