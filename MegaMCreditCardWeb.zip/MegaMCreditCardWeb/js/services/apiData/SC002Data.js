var SC002RqData = function() {
	// 不需帶資料
}

var SC002RsData = function() {
	// 沒有回傳資料
}