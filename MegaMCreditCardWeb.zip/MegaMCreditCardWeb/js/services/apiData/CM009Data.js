var CM009RqData = function() {
	this.file = "";
	this.fileName = "";
}

var CM009RsData = function() {
	// 沒有回傳資料
}