var SC001RqData = function() {
	// 不需帶資料
}

var SC001RsData = function() {
	this.tokenID =  "";
	this.aesKey = "";
	this.gOTP = "";
	this.tokenTime = "";
	this.timeoutAlertTime = "";
}