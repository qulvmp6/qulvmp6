var VR003RqData = function() {
	this.custID = "";
	this.birthday = "";
}

var VR003RsData = function() {
	this.seqNo = "";
	this.maskPhone = "";
}