var VR011RqData = function() {
	this.bank = "";
	this.account = "";
	this.primID = "";
	this.phoneNo = "";
	this.birthDay = "";
	this.otp = "";
}

var VR011RsData = function() {
	this.uuid =  "";
}