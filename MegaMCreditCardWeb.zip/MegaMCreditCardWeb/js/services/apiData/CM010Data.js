var CM010RqData = function() {
	this.toPDF = "";
	this.isOrigin = "";
	this.cardCode = "";
	this.cPrimChName = "";
	this.cPrimEngName = "";
	this.cPrimBirthday = "";
	this.cPrimId = "";
	this.cardIDCDate = "";
	this.cCityCardIssue = "";
	this.cCityCodeCardIssue = "";
	this.cardIDCFlag = "";
	this.mPrimEducation = "";
	this.mPrimMarriage = "";
	this.cPrimAddr2Zip = "";
	this.cPrimAddr2 = "";
	this.cPrimAddr1Zip = "";
	this.cPrimAddr1 = "";
	this.cPrimHomeTelNo1a = "";
	this.cPrimHomeTelNo1b = "";
	this.cPrimHomeTelNo1c = "";
	this.cPrimHomeTelNo2a = "";
	this.cPrimHomeTelNo2b = "";
	this.cPrimHomeTelNo2c = "";
	this.cPrimCellulaNo1 = "";
	this.mPrimAddr1Cond = "";
	this.cPrimAddr1LiveYear = "";
	this.cPrimEmail = "";
	this.cPrimCompany = "";
	this.cPrimJobTitle = "";
	this.mPrimJob = "";
	this.cNote4 = "";
	this.cPrimGraduateDate = "";
	this.cPrimSalary = "";
	this.cPrimOfficeTelNo1a = "";
	this.cPrimOfficeTelNo1b = "";
	this.cPrimOfficeTelNo1c = "";
	this.mBillTo = "";
	this.cPrimAddr3Zip = "";
	this.cPrimAddr3 = "";
	this.mAcceptDm = "";
	this.cIntrId = "";
	this.cIntrCode = "";
	this.mCardTo = "";
	this.cNote10 = "";
	this.mNormalCardOpt = "";
	this.cPayMentDueDate = "";
	this.mBillByMail = "";
	this.mBillDesc = "";
	this.mNote9 = "";
	this.cPrimAccountNo = "";
	this.cAccount = "";
	this.mIdentifyType = "";
	this.cBrandedCardFlag = "";
	this.feeCode = "";
	this.law_bank = "";
	this.law_protect = "";
	this.law_fee = "";
	this.law_obey = "";
	this.law_agree = "";
	this.idFileF = "";
	this.idFileFExtName = "";
	this.idFileB = "";
	this.idFileBExtName = "";
	this.attachments = [];

	// "attachments": [
	//     {
	//       "file": "c3NzZGRmMTIzNDQ......",
	//       "fileExtName": "jpg"},
	//     {
	//       "file": "c3NzZGRmMTIzNDQ......",
	//       "fileExtName": "jpg"}
	//   ]
}

var CM010RsData = function() {
	this.resultPDF = "";
}