var CM008RqData = function() {
	// 不需帶資料
}

var CM008RsData = function() {
	this.preDate = "";
	this.serNo = "";
}