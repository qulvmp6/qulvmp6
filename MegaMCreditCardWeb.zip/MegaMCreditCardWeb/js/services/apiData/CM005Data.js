var CM005RqData = function() {
	this.cardCode = "";
}

var CM005RsData = function() {
	this.leadingText = "";
	this.article = "";
}