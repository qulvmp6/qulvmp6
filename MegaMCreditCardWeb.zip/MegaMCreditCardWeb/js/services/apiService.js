// CommonRequest structure
var CommonRequest = function() {
	this.requestHeader = {
	    timeStamp : "",
	    tokenID : ""
	};
	this.requestBody = {
	    data : ""
	}
};

// CommonResponse structure
/*
	{
		responseHeader : {
			returnCode : "",
			returnMsg : ""
		},
		responseBody : {
			data : ""
		}
	} 
*/

var ApiService = function() {
	var e = this;
	e.apiConfig = {
		GATEWAY_URL : geteway_url(),
		/** DEV */
		// GATEWAY_URL: "http://10.1.16.213:8080/MegaMCreditCard/rest/creditcard/",
		// GATEWAY_URL: "http://10.1.16.179:8080/MegaMCreditCard/rest/creditcard/",

		/** UAT */
		// GATEWAY_URL: "https://192.168.53.157:452/MegaMCreditCard/rest/creditcard/",
		// GATEWAY_URL: "https://192.168.53.54:452/MegaMCreditCard/rest/creditcard/",

		/** PDT */
		// GATEWAY_URL: "https://ebank.megabank.com.tw/MegaMCreditCard/rest/creditcard/",

		API_SC001: "SC001",
		API_SC002: "SC002",
		API_CM001: "CM001",
		API_CM002: "CM002",
		API_CM003: "CM003",
		API_CM004: "CM004",
		API_CM005: "CM005",
		API_CM006: "CM006",
		API_CM008: "CM008",
		API_CM009: "CM009",
		API_CM010: "CM010",
		API_VR001: "VR001",
		API_VR002: "VR002",
		API_VR003: "VR003",
		API_VR004: "VR004",
		API_VR011: "VR011",
		API_VR012: "VR012"
	};

	e.returnCode = {
		SUCCESS: "0000",
		DATA_NOT_FOUND: "D0001",
		SMS_OTP_PWD_INVALID: "SC0011"
	};

	e.errorMsg = {
		TIMEOUT: "很抱歉，目前無法處理您的指令。若有任何問題，請洽本行客服中心 (02)8982-0000。(Err Code：timeout)",
		HTTP_STATUS_500: "很抱歉，目前無法處理您的指令。若有任何問題，請洽本行客服中心 (02)8982-0000。(Err Code：500)",
		HTTP_STATUS_503_AND_0: "很抱歉，資料發生錯誤，請您重新申請，謝謝。線上辦卡問題可洽本行客服 (02)8982-0000。",
		HTTP_STATUS_Other: "很抱歉，本服務目前處於維護時期。若有任何問題，請洽本行客服中心 (02)8982-0000。",
		CM010_HTTP_STATUS_503_AND_0: "很抱歉，申請資料上傳時發生錯誤，線上申請信用卡{highKey}失敗{/highKey}，請您重新申請，謝謝。線上辦卡問題可洽本行客服 (02)8982-0000。"
	};

	e.commonErrorFun = function(xhr, status) {
		if(status === 'timeout') {
			showErrorPage(e.errorMsg.TIMEOUT);
		} else {
			if(xhr.status == 500) {
				showErrorPage(e.errorMsg.HTTP_STATUS_500);
			} else if(xhr.status == 503 || xhr.status == 0) {
				showErrorPage(e.errorMsg.HTTP_STATUS_503_AND_0 + "(Err Code：" + xhr.status + ")");
			} else {
				showErrorPage(e.errorMsg.HTTP_STATUS_Other + "(Err Code：" + xhr.status + ")");
			}
		}
	};

	e.particularStatusErrorFun = function(xhr, status, jqDeffered) {
		if(status === 'timeout') {
			showErrorPage(e.errorMsg.TIMEOUT);
		} else {
			if(xhr.status == 500) {
				showErrorPage(e.errorMsg.HTTP_STATUS_500);
			} else if(xhr.status == 503 || xhr.status == 0) {
				console.log("apiService.particularStatusErrorFun catch http status " + xhr.status);
				jqDeffered.reject(xhr.status);
			} else {
				showErrorPage(e.errorMsg.HTTP_STATUS_Other + "(Err Code：" + xhr.status + ")");
			}
		}
	};

	e.handleResponse = function(response, jqDeffered) {
		if(response.responseHeader.returnCode == e.returnCode.SUCCESS) {
			var rsDataJSON = response.responseBody.data;
			jqDeffered.resolve(rsDataJSON);
		} else {
			showErrorPage(response.responseHeader.returnMsg);
		}
	};

	// 回傳整個response，由呼叫方進行判斷與錯誤處理
	e.handleResponseFullReturn = function(response, jqDeffered) {
		jqDeffered.resolve(response);
	};

	e.doSC001 = function() {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_SC001);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_SC001,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doSC002 = function() {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_SC002);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_SC002,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);
		
		return deferred.promise();
	};

	e.doCM001 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM001);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestBody.data = rqDataJSON;

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM001,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);
		
		return deferred.promise();
	};

	e.doCM002 = function() {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM002);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM002,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM003 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM003);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestBody.data = rqDataJSON;
		
		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM003,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM004 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM004);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = rqDataJSON;

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM004,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM005 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM005);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = rqDataJSON;

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM005,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					var rsDataJSON = "";
					if(response.responseHeader.returnCode == e.returnCode.SUCCESS) {
						rsDataJSON = response.responseBody.data;
						deferred.resolve(rsDataJSON);
					} else if(response.responseHeader.returnCode == e.returnCode.DATA_NOT_FOUND) {
						// 表示非聯名卡
						rsDataJSON = "";
						deferred.resolve(rsDataJSON);
					} else {
						deferred.reject();
						e.showErrorPage(response.responseHeader.returnMsg);
					}
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM006 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM006);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}
		
		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestBody.data = AESUtil.encrypt(encodeURIComponent(rqDataJSON), window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM006,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM008 = function() {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM008);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM008,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doCM009 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM009);
			deferred.resolve(JSON.parse(rsDataJSONMock));
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM009,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponseFullReturn(response, deferred);
				}
			},
			function(xhr, status) {
				e.particularStatusErrorFun(xhr, status, deferred);
			}
		);

		return deferred.promise();
	};
	
	e.doCM010 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_CM010);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(encodeURIComponent(rqDataJSON), window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_CM010 + "?t=" + new Date().getTime().toString(),
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			function(xhr, status) {
				e.particularStatusErrorFun(xhr, status, deferred);
			}
		);

		return deferred.promise();
	};

	e.doVR001 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR001);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR001,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doVR002 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR002);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR002,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doVR003 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR003);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR003,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doVR004 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR004);
			deferred.resolve(JSON.parse(rsDataJSONMock));
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR004,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					// 非所有錯誤情境皆導錯誤頁，因此回傳整個response，由呼叫方進行判斷與錯誤處理
					e.handleResponseFullReturn(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};

	e.doVR011 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR011);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR011,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};
	
	e.doVR012 = function(rqDataJSON) {
		var deferred = $.Deferred();

		if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
			var rsDataJSONMock = e.getMockResult(e.apiConfig.API_VR012);
			deferred.resolve(rsDataJSONMock);
			return deferred.promise();
		}

		var rqbody = new CommonRequest();
		rqbody.requestHeader.timeStamp = window.btoa(new Date().getTime().toString());
		rqbody.requestHeader.tokenID = localStorage.getItem(LSKey.TOKEN_ID);
		rqbody.requestBody.data = AESUtil.encrypt(rqDataJSON, window.atob(localStorage.getItem(LSKey.AES_KEY)));

		Ajax.Post(
			e.apiConfig.GATEWAY_URL + e.apiConfig.API_VR012,
			JSON.stringify(rqbody),
			function(response) {
				if(response) {
					e.handleResponse(response, deferred);
				}
			},
			e.commonErrorFun
		);

		return deferred.promise();
	};
	
	e.getMockResult = function(apiName) {
		var mockResultJSON = "";
		switch(apiName) {
			case e.apiConfig.API_SC001:
				mockResultJSON = {
					"tokenID": "MOCK_ZTQ2ZGUyMmZNjgxNDBjYWI5MGVhOTZlMzM4ODUyNDliNA==",
					"aesKey": "MOCK_SIb3DQEBAQUAA4GNADCBiQKBgQCton5uZdFcMFGVgI7...",
					"gOTP": "assets/test_gotp.jpg",
					"tokenTime": "300",
					"timeoutAlertTime": "60"
				};
				break;
			case e.apiConfig.API_SC002:
				// 沒有回傳資料
				break;
			case e.apiConfig.API_CM001:
				mockResultJSON = {
					"articles": [
						{
							"articleCode": "C1",
							"article": "MOCK個人網路銀行業務服務契約約定條款",
							"version": "20151112"
						},
						{
							"articleCode": "C2",
							"article": "MOCK個資法告知義務",
							"version": "20151112"
						},
						{
							"articleCode": "C3",
							"article": "MOCK信用卡利率與費用計算說明",
							"version": "20151112"
						},
						{
							"articleCode": "C4",
							"article": "MOCK用卡須知",
							"version": "20151112"
						},
						{
							"articleCode": "C5",
							"article": "MOCK申請聲明同意條款",
							"version": "20151112"
						},
						{
							"articleCode": "F1",
							"article": 
								"<div class='c-footer'><div class='c-footer__title'>MOCK謹慎理財 信用至上</div><div class='c-footer__content'>一般消費及預借現金之循環利率依本行『新台幣一年期定期儲蓄存款固定利率』加碼年息4.43%~15%，及上限利率15%，共分七級。預借現金手續費：每筆預借現金金額X3%+NT$150‧其他費用及活動詳情請上兆豐銀行網站查詢。</div></div>",
							"version": ""
						},
						{
							"articleCode": "F2",
							"article": "<div class='c-paragraph'>MOCK您可使用以下銀行所發行之信用卡進行身分證驗：<br>玉山商業銀行、台新國際商業銀行、花旗(台灣)銀行、聯邦商業銀行、永豐商業銀行、遠東國際商業銀行、華南商業銀行、臺灣新光商業銀行、元大銀行、匯豐(台灣)商業銀行、台灣樂天信用卡股份有限公司、台中商業銀行、日盛國際商業銀行、陽信商業銀行、台灣永旺信用卡股份有限公司、三信商業銀行、星展(台灣)商業銀行、華泰商業銀行等。</div>",
							"version": ""
						},
						{
							"articleCode": "F21",
							"article": "<div class='c-paragraph'>MOCK您可使用以下銀行存款帳戶(須為臨櫃開立之存款帳戶)進行身分驗證：<br>004臺灣銀行、009彰化商業銀行、012台北富邦商業銀行、016高雄銀行、017兆豐國際商業銀行、054京城商業銀行、103臺灣新光商業銀行、108陽信商業銀行、118板信商業銀行、216花蓮第二信用合作社、805遠東國際商業銀行、815日盛國際商業銀行、928板橋區農會電腦共用中心等。</div>",
							"version": ""
						},
						{
							"articleCode": "F3",
							"article": 
								"<div class='c-paragraph'>MOCK正卡申請人已經詳細閱讀並同意兆豐國際商業銀行於<span style='font-size: .563em;''>https://www.megabank.com.tw</span>網站線上申請信用卡所揭示之個人網路銀行業務服務契約、信用卡循環利率及各項費用之收費標準，並同意遵守用卡須知及隨卡附上之信用卡約定條款，及同意貴行有權經正式公告調整上述所列支各項條款、費用及利率。</div>",
							"version": ""
						},
						{
							"articleCode": "F4",
							"article": "MOCK申請資格說明",
							"version": ""
						}
					]
				};
				break;
			case e.apiConfig.API_CM002:
				mockResultJSON = {
					"cityCardIssue": [
						{"key":"11111111", "value":"台北市"},
						{"key":"22222222", "value":"新北市"},
						{"key":"33333333", "value":"高雄市"}],
					"cardIDCFlag": [
						{"key":"1", "value":"初發"},
						{"key":"2", "value":"補發"},
						{"key":"3", "value":"換發"}],
					"marriage": [
						{"key":"1", "value":"己婚"},
						{"key":"2", "value":"未婚"}],
					"education": [
						{"key":"1", "value":"高中"},
						{"key":"2", "value":"大學"},
						{"key":"3", "value":"研究所"}],
					"telZoneNum": [
						{"key":"000", "value":"000"},
						{"key":"001", "value":"001"},
						{"key":"002", "value":"002"}],
					"addrCond": [
						{"key":"1", "value":"狀況1"},
						{"key":"2", "value":"狀況2"},
						{"key":"3", "value":"狀況3"}],
					"job": [
						{"key":"1", "value":"負責人/高階主管"},
						{"key":"2", "value":"中階/基層主管"},
						{"key":"3", "value":"軍/警/消/公教人員"},
						{"key":"4", "value":"內勤人員"},
						{"key":"5", "value":"駐外/外勤人員"},
						{"key":"6", "value":"業務人員"},
						{"key":"7", "value":"專業人士"},
						{"key":"8", "value":"自由業"},
						{"key":"9", "value":"專業技師"},
						{"key":"10", "value":"學生"},
						{"key":"11", "value":"其他/家管"}],
					"payMentDueDate": [
						{"key":"1", "value":"d1"},
						{"key":"2", "value":"d2"}],
					"addrZone": [
						{
							"city":"台北市", 
							"dists":[
								{"dist":"中正區", "postalCode":"100"},
								{"dist":"大同區", "postalCode":"103"}]
						},
						{
							"city":"新北市", 
							"dists":[
								{"dist":"萬里", "postalCode":"207"},
								{"dist":"金山", "postalCode":"208"}]
						}
					]
				};
				break;
			case e.apiConfig.API_CM003:
				mockResultJSON = {
					"defaultCard": "30155",
					"cIntrId": "9527",
					"creditCards": [
						{
							"cardName": "e秒刷一卡通鈦金卡", 
							"cardKinds": [
								{
									"cardKind":"e秒刷一卡通鈦金卡",
									"cardCode":"40230", 
									"picUrl":"https://dummyimage.com/600x400/000/fff.png&text=e秒刷一卡通鈦金卡40230",
									"feeCode":"1",
									"eBill":"Y",
									"isCombo":"Y",
									"additional":"MOCK補充條款，申辦一卡通聯名卡重要聲明，務必注意n本人同意 基於  貴行與一卡通公司合作關係，提供個人基本資料（姓名、身分證字號、生日、電話、地址、e-mail）予一卡通公司作為記名式一卡通聯名卡使用。配合個人資料保護法實施，一卡通公司已將應告知事項載於官網www.i-pass.com.tw，若有任何疑慮，歡迎您撥打一卡通客服專線（07）791-2000洽詢，謝謝。一卡通自動加值功能預設為開啟。（如不同意，則無法申辦本聯名卡）"
								}
							]
						},
						{
							"cardName": "幸福卡", 
							"cardKinds": [
								{
									"cardKind":"幸福普卡", 
									"cardCode":"30155", 
									"picUrl":"https://dummyimage.com/300x200/000/fff.png&text=幸福普卡30155",
									"feeCode":"2",
									"eBill":"N",
									"isCombo":"Y",
									"additional":"MOCK信用卡補充條款222"
								},
								{
									"cardKind":"幸福鈦金卡", 
									"cardCode":"30156", 
									"picUrl":"https://dummyimage.com/300x200/000/fff.png&text=幸福鈦金卡30156",
									"feeCode":"3",
									"eBill":"Y",
									"isCombo":"N",
									"additional":""
								}
							]
						}
					]
				};
				break;
			case e.apiConfig.API_CM004:
				mockResultJSON = {
					"branches": [
					    {"code":"406", "name":"衡陽分行"},
					    {"code":"170", "name":"城中分行"},
					    {"code":"309", "name":"南台北分行"}
					  ]
				};
				break;
			case e.apiConfig.API_CM005:
				mockResultJSON = {
					"leadingText": "本人",
					"article": "MOCK基於　貴行與一卡通公司合作關係，提供個人基本資料......"
				};
				break;
			case e.apiConfig.API_CM006:
				mockResultJSON = {
					"items": [
					    {"bankCode":"001", "bankName":"中國信托"},
					    {"bankCode":"002", "bankName":"土地銀行"},
					    {"bankCode":"004", "bankName":"台灣銀行"}
					  ]
				};
				break;
			case e.apiConfig.API_CM008:
				mockResultJSON = {
					"preDate": "20190719114243",
					"serNo": "004"
				};
				break;
			case e.apiConfig.API_CM009:
				mockResultJSON = {
					"responseHeader": {
						"returnCode": "0000",
						"returnMsg": "success"
					},
					"responseBody": {
						"data": ""
					}
				};
				break;
			case e.apiConfig.API_CM010:
				mockResultJSON = {
					"resultPDF": "JVBERi0xLjcKCjEgMCBvYmogICUgZW50cnkgcG9pbnQKPDwKICAvVHlwZSAvQ2F0YWxvZwogIC9QYWdlcyAyIDAgUgo+PgplbmRvYmoKCjIgMCBvYmoKPDwKICAvVHlwZSAvUGFnZXMKICAvTWVkaWFCb3ggWyAwIDAgMjAwIDIwMCBdCiAgL0NvdW50IDEKICAvS2lkcyBbIDMgMCBSIF0KPj4KZW5kb2JqCgozIDAgb2JqCjw8CiAgL1R5cGUgL1BhZ2UKICAvUGFyZW50IDIgMCBSCiAgL1Jlc291cmNlcyA8PAogICAgL0ZvbnQgPDwKICAgICAgL0YxIDQgMCBSIAogICAgPj4KICA+PgogIC9Db250ZW50cyA1IDAgUgo+PgplbmRvYmoKCjQgMCBvYmoKPDwKICAvVHlwZSAvRm9udAogIC9TdWJ0eXBlIC9UeXBlMQogIC9CYXNlRm9udCAvVGltZXMtUm9tYW4KPj4KZW5kb2JqCgo1IDAgb2JqICAlIHBhZ2UgY29udGVudAo8PAogIC9MZW5ndGggNDQKPj4Kc3RyZWFtCkJUCjcwIDUwIFRECi9GMSAxMiBUZgooSGVsbG8sIHdvcmxkISkgVGoKRVQKZW5kc3RyZWFtCmVuZG9iagoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDEwIDAwMDAwIG4gCjAwMDAwMDAwNzkgMDAwMDAgbiAKMDAwMDAwMDE3MyAwMDAwMCBuIAowMDAwMDAwMzAxIDAwMDAwIG4gCjAwMDAwMDAzODAgMDAwMDAgbiAKdHJhaWxlcgo8PAogIC9TaXplIDYKICAvUm9vdCAxIDAgUgo+PgpzdGFydHhyZWYKNDkyCiUlRU9G"
				};
				break;
			case e.apiConfig.API_VR001:
				mockResultJSON = {
					"primChName": "王小華",
					"cardFlag": "1",
					"billAddr": "信義路555段555巷555號555樓６６６號",
					"autoPayIndicator": "1",
					"autoPayAcctBank": "812",
					"autoPayAcctNo": "1234567891234567",
					"phoneNo": "0911111111"
				};
				break;
			case e.apiConfig.API_VR002:
				// 沒有回傳資料
				break;
			case e.apiConfig.API_VR003:
				mockResultJSON = {
					"seqNo": "OXJA",
					"maskPhone": "0952XXX333"
				};
				break;
			case e.apiConfig.API_VR004:
				var tmpDataObj = {
					"primChName": "王小華",
					"cardFlag": "1",
					"billAddr": "信義路555段555巷555號555樓６６６號",
					"autoPayIndicator": "1",
					"autoPayAcctBank": "812",
					"autoPayAcctNo": "1234567891234567",
					"phoneNo": "0911111111"
				};

				mockResultJSON = {
					"responseHeader": {
						"returnCode": "0000",
						"returnMsg": "success"
					},
					"responseBody": {
						"data": JSON.stringify(tmpDataObj)
					}
				};
				break;
			case e.apiConfig.API_VR011:
				mockResultJSON = {
					"uuid": "123415231vsadvsavsdvsyuiowuegbfwoqubgvwoq"
				};
				break;
			case e.apiConfig.API_VR012:
				mockResultJSON = {
					"isCardFriend": "Y",
					"primChName": "王小華",
					"billAddr": "信義路555段555巷555號555樓６６６號",
					"autoPayIndicator": "1",
					"autoPayAcctBank": "812",
					"autoPayAcctNo": "1234567891234567",
					"phoneNo": "0911111111"
				};
				break;
		}
		return JSON.stringify(mockResultJSON);
	};
};
